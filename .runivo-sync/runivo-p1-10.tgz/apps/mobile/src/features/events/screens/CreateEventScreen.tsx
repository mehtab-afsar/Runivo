import React, { useMemo } from 'react';
import { View, Text, StyleSheet, ScrollView, Pressable, SafeAreaView, Platform, KeyboardAvoidingView } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import type { RootStackParamList } from '@navigation/AppNavigator';
import { useCreateEvent } from '../hooks/useCreateEvent';
import { EventForm } from '../components/EventForm';
import { Fonts, useTheme, type AppColors } from '@theme';

type Nav = NativeStackNavigationProp<RootStackParamList>;

export default function CreateEventScreen() {
  const navigation = useNavigation<Nav>();
  const C = useTheme();
  const s = useMemo(() => mkStyles(C), [C]);
  const {
    saving, error, canSubmit,
    title, setTitle, eventType, setEventType,
    date, setDate, time, setTime,
    location, setLocation, distanceKm, setDistanceKm,
    description, setDescription, discipline, setDiscipline, submit,
  } = useCreateEvent();

  const handleSubmit = async () => {
    const ok = await submit();
    if (ok) navigation.goBack();
  };

  return (
    <SafeAreaView style={s.root}>
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
        <View style={s.header}>
          <Pressable onPress={() => navigation.goBack()} style={s.back}>
            <Text style={s.backText}>←</Text>
          </Pressable>
          <Text style={s.title}>Create Event</Text>
          <View style={{ width: 32 }} />
        </View>

        <ScrollView contentContainerStyle={s.content} showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled">
          <EventForm
            saving={saving} error={error} canSubmit={canSubmit}
            title={title} setTitle={setTitle}
            eventType={eventType} setEventType={setEventType}
            date={date} setDate={setDate}
            time={time} setTime={setTime}
            location={location} setLocation={setLocation}
            distanceKm={distanceKm} setDistanceKm={setDistanceKm}
            description={description} setDescription={setDescription}
            discipline={discipline} setDiscipline={setDiscipline}
            onSubmit={handleSubmit}
          />
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

function mkStyles(C: AppColors) {
  return StyleSheet.create({
  root: { flex: 1, backgroundColor: C.surface },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 18, paddingTop: Platform.OS === 'android' ? 12 : 0, paddingBottom: 12 },
  back: { width: 32 }, backText: { fontFamily: Fonts.regular, fontSize: 18, color: C.t2 },
  title: { fontFamily: Fonts.semiBold, fontSize: 20, color: C.t1 },
  content: { paddingHorizontal: 18, paddingBottom: 60, gap: 4 },
  });
}
