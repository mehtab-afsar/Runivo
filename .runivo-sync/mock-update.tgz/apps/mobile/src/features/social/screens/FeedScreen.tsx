import React, { useState, useEffect, useRef, useMemo, useCallback } from 'react';
import {
  View, Text, StyleSheet, FlatList, Pressable, SafeAreaView,
  RefreshControl, Platform, Animated, ScrollView,
  Modal, TextInput, useWindowDimensions,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import type { RootStackParamList } from '@navigation/AppNavigator';
import { Search, Check, Plus, UserPlus, X } from 'lucide-react-native';
import { useFeed } from '@features/social/hooks/useFeed';
import { FeedPostCard } from '@features/social/components/FeedPostCard';
import CommentSheet from '@features/social/components/CommentSheet';
import { EmptyFeed } from '@features/social/components/EmptyFeed';
import { FeedSkeleton } from '@features/social/components/FeedSkeleton';
import { StoryReel } from '@features/social/components/StoryReel';
import { ClubActivityStrip } from '@features/social/components/ClubActivityStrip';
import { fetchStories, type StoryGroup } from '@features/social/services/storyService';
import { supabase } from '@shared/services/supabase';
import { Avatar } from '@mobile/shared/components/Avatar';
import { useTheme, Type, Fonts, Spacing, type AppColors } from '@theme';
import type { FeedPost, SuggestedRunner } from '@features/social/types';
import type { ClubFeedActivityItem } from '@features/clubs/types';

type Nav = NativeStackNavigationProp<RootStackParamList>;
type Tab = 'following' | 'discover';

export default function FeedScreen() {
  const C = useTheme();
  const s = useMemo(() => mkStyles(C), [C]);
  const { width } = useWindowDimensions();
  const navigation = useNavigation<Nav>();

  const [tab, setTab]                     = useState<Tab>('following');
  const [commentPostId, setCommentPostId] = useState<string | null>(null);
  const [stories, setStories]             = useState<StoryGroup[]>([]);
  const [searchVisible, setSearchVisible] = useState(false);
  const [runnerQuery, setRunnerQuery]     = useState('');

  const tabX = useRef(new Animated.Value(0)).current;
  const TAB_W = (width - 36) / 2;

  const {
    followingPosts,
    discoverPosts,
    followingHasMore,
    discoverHasMore,
    loading,
    refreshing,
    followingIds,
    suggestedRunners,
    clubActivity,
    userId,
    loadMore,
    switchToDiscover,
    toggleKudos,
    toggleFollow,
    refresh,
    onCommentPosted,
    deletePost,
  } = useFeed();

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (session?.user.id) fetchStories(session.user.id).then(setStories).catch(() => {});
    });
  }, []);

  const switchTab = useCallback((t: Tab) => {
    setTab(t);
    Animated.timing(tabX, {
      toValue: t === 'following' ? 0 : TAB_W,
      duration: 200,
      useNativeDriver: true,
    }).start();
    if (t === 'discover') switchToDiscover();
  }, [tabX, TAB_W, switchToDiscover]);

  const posts = tab === 'following' ? followingPosts : discoverPosts;
  const hasMore = tab === 'following' ? followingHasMore : discoverHasMore;

  // Same runner list Discover's "Runners near you" strip already fetched
  // (useFeed loads it on mount, not gated behind switching tabs) — typed
  // query just filters it client-side rather than a third implementation
  // of the same search.
  const runnerResults = useMemo(() => {
    if (!runnerQuery.trim()) return suggestedRunners;
    const q = runnerQuery.trim().toLowerCase();
    return suggestedRunners.filter(r => r.username.toLowerCase().includes(q));
  }, [suggestedRunners, runnerQuery]);

  // "Take it back": straight to a run.
  const handleDefend = useCallback(() => {
    navigation.navigate('Main', { screen: 'Run' });
  }, [navigation]);

  const renderPost = useCallback(({ item }: { item: FeedPost }) => (
    <FeedPostCard
      post={item}
      currentUserId={userId}
      onKudos={() => toggleKudos(item.id)}
      onComment={() => setCommentPostId(item.id)}
      onUserPress={() => navigation.navigate('UserProfile', { userId: item.userId, username: item.username })}
      onDelete={() => deletePost(item.id)}
      onDefend={item.postType === 'attack' ? handleDefend : undefined}
    />
  ), [toggleKudos, navigation, userId, deletePost, handleDefend]);

  const keyExtractor = useCallback((item: FeedPost) => item.id, []);

  const goToDiscover = useCallback(() => switchTab('discover'), [switchTab]);
  const goToRun = useCallback(() => navigation.navigate('Run' as never), [navigation]);

  const goToClub = useCallback((item: ClubFeedActivityItem) => {
    navigation.navigate('ClubDetail', {
      clubId: item.clubId, clubName: item.clubName, badgeEmoji: item.badgeEmoji,
      memberCount: item.memberCount, totalKm: item.totalKm,
    });
  }, [navigation]);

  const DiscoverHeader = useMemo(() => {
    if (tab !== 'discover' || suggestedRunners.length === 0) return null;
    return (
      <View style={s.suggestedSection}>
        <Text style={[Type.overline, s.suggestedLabel]}>Runners near you</Text>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={s.suggestedScroll}>
          {suggestedRunners.map(runner => {
            const isFollowing = followingIds.includes(runner.id);
            const isSelf = runner.id === userId;
            return (
              <Pressable
                key={runner.id}
                style={s.runnerCard}
                onPress={() => navigation.navigate('UserProfile', { userId: runner.id, username: runner.username })}
              >
                <View style={s.runnerAvatarWrap}>
                  <Avatar name={runner.username} color={runner.avatarColor} size={48} uri={runner.avatarUrl} />
                  {!isSelf && (
                    <Pressable style={s.followDot} onPress={() => toggleFollow(runner.id)}>
                      {isFollowing
                        ? <Check size={9} color={C.white} strokeWidth={2.5} />
                        : <Plus  size={9} color={C.white} strokeWidth={2.5} />}
                    </Pressable>
                  )}
                </View>
                <Text style={s.runnerName} numberOfLines={1}>{runner.username.split(' ')[0]}</Text>
                <Text style={s.runnerScore}>{Intl.NumberFormat().format(runner.territoryScore)}</Text>
              </Pressable>
            );
          })}
        </ScrollView>
      </View>
    );
  }, [tab, suggestedRunners, followingIds, userId, C, s, navigation, toggleFollow]);

  const FollowingHeader = useMemo(() => {
    if (tab !== 'following') return null;
    if (stories.length === 0 && clubActivity.length === 0) return null;
    return (
      <>
        {stories.length > 0 && (
          <StoryReel
            groups={stories}
            onPress={(_g, i) => navigation.navigate('StoryViewer', { groups: stories, initialGroupIndex: i })}
          />
        )}
        <ClubActivityStrip items={clubActivity} onPress={goToClub} />
      </>
    );
  }, [tab, stories, clubActivity, navigation, goToClub]);

  return (
    <SafeAreaView style={s.root}>
      {/* Header: title + runner search (there's no direct-messages feature to link yet) */}
      <View style={s.titleRow}>
        <Text style={s.title}>Feed</Text>
        <Pressable onPress={() => setSearchVisible(true)} hitSlop={10} style={s.searchIcon} accessibilityLabel="Search runners">
          <Search size={19} color={C.t1} strokeWidth={1.9} />
        </Pressable>
      </View>
      <View style={s.header}>
        <View style={s.pillTrack}>
          <Animated.View style={[s.pillActive, { width: TAB_W - 6, transform: [{ translateX: tabX }] }]} />
          <Pressable style={s.tabItem} onPress={() => switchTab('following')}>
            <Text style={[s.tabLabel, tab === 'following' && s.tabLabelActive]}>Following</Text>
          </Pressable>
          <Pressable style={s.tabItem} onPress={() => switchTab('discover')}>
            <Text style={[s.tabLabel, tab === 'discover' && s.tabLabelActive]}>Discover</Text>
          </Pressable>
        </View>
      </View>

      {loading ? (
        <FeedSkeleton />
      ) : (
        <FlatList
          data={posts}
          keyExtractor={keyExtractor}
          renderItem={renderPost}
          showsVerticalScrollIndicator={false}
          contentContainerStyle={s.list}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => refresh(tab)} tintColor={C.red} />}
          onEndReached={hasMore ? () => loadMore(tab) : undefined}
          onEndReachedThreshold={0.4}
          ListHeaderComponent={tab === 'following' ? FollowingHeader : DiscoverHeader}
          ListEmptyComponent={
            <EmptyFeed
              tab={tab === 'following' ? 'following' : 'explore'}
              onCta={tab === 'following' ? goToDiscover : goToRun}
            />
          }
          ListFooterComponent={hasMore ? <FooterSpinner C={C} /> : null}
        />
      )}

      <CommentSheet
        postId={commentPostId}
        onClose={() => setCommentPostId(null)}
        onCommentPosted={onCommentPosted}
      />

      {/* Runner search modal */}
      <Modal visible={searchVisible} animationType="slide" transparent={false} onRequestClose={() => setSearchVisible(false)}>
        <SafeAreaView style={s.searchModal}>
          <View style={s.searchHeader}>
            <TextInput
              style={s.searchInput}
              placeholder="Search runners…"
              placeholderTextColor={C.t3}
              value={runnerQuery}
              onChangeText={setRunnerQuery}
              autoFocus
              autoCapitalize="none"
              autoCorrect={false}
            />
            <Pressable onPress={() => { setSearchVisible(false); setRunnerQuery(''); }} hitSlop={8}>
              <X size={18} color={C.t2} strokeWidth={1.75} />
            </Pressable>
          </View>
          {!runnerQuery.trim() && (
            <Text style={[Type.overline, s.suggestedLabel]}>Suggested</Text>
          )}
          <FlatList
            data={runnerResults}
            keyExtractor={r => r.id}
            renderItem={({ item }) => (
              <RunnerRow
                runner={item}
                isFollowing={followingIds.includes(item.id)}
                isSelf={item.id === userId}
                onPress={() => { setSearchVisible(false); navigation.navigate('UserProfile', { userId: item.id, username: item.username }); }}
                onFollow={() => toggleFollow(item.id)}
              />
            )}
            showsVerticalScrollIndicator={false}
            contentContainerStyle={s.list}
            ListEmptyComponent={
              runnerQuery.trim()
                ? <Text style={s.searchEmpty}>No runners match "{runnerQuery.trim()}"</Text>
                : null
            }
          />
        </SafeAreaView>
      </Modal>
    </SafeAreaView>
  );
}

// Same row for both the default "Suggested" list and typed-query results —
// no separate layout for the two states.
function RunnerRow({
  runner, isFollowing, isSelf, onPress, onFollow,
}: {
  runner: SuggestedRunner;
  isFollowing: boolean;
  isSelf: boolean;
  onPress: () => void;
  onFollow: () => void;
}) {
  const C = useTheme();
  const s = useMemo(() => mkRowStyles(C), [C]);
  return (
    <Pressable style={s.row} onPress={onPress}>
      <Avatar name={runner.username} color={runner.avatarColor} size={44} uri={runner.avatarUrl} />
      <View style={s.info}>
        <Text style={s.name} numberOfLines={1}>{runner.username}</Text>
        <Text style={s.score}>{Intl.NumberFormat().format(runner.territoryScore)} territory score</Text>
      </View>
      {!isSelf && (
        <Pressable
          style={[s.followBtn, isFollowing && s.followBtnActive]}
          onPress={onFollow}
        >
          {isFollowing
            ? <Check size={13} color={C.t2} strokeWidth={2} />
            : <UserPlus size={13} color={C.alwaysLight} strokeWidth={2} />}
        </Pressable>
      )}
    </Pressable>
  );
}

function mkRowStyles(C: AppColors) {
  return StyleSheet.create({
    row:          { flexDirection: 'row', alignItems: 'center', gap: 12, paddingHorizontal: Spacing.gutter, paddingVertical: 10 },
    info:         { flex: 1 },
    name:         { fontFamily: Fonts.medium, fontSize: 14, color: C.black },
    score:        { fontFamily: Fonts.regular, fontSize: 11, color: C.t3, marginTop: 2 },
    followBtn:    { width: 32, height: 32, borderRadius: 16, backgroundColor: C.alwaysDark, alignItems: 'center', justifyContent: 'center' },
    followBtnActive: { backgroundColor: C.stone, borderWidth: 0.5, borderColor: C.border },
  });
}

function FooterSpinner({ C }: { C: AppColors }) {
  // A single small pulse rather than importing ActivityIndicator's OS-default
  // spinner mid-list — keeps pagination feedback consistent with the skeleton
  // above rather than switching visual languages mid-scroll.
  return <View style={{ paddingVertical: 20, alignItems: 'center' }}><Text style={{ color: C.t3, fontFamily: Fonts.regular, fontSize: 11 }}>Loading more…</Text></View>;
}

function mkStyles(C: AppColors) {
  return StyleSheet.create({
    root:           { flex: 1, backgroundColor: C.bg },
    titleRow:       { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 18, paddingTop: Platform.OS === 'android' ? 12 : 6, paddingBottom: 10 },
    title:          { fontFamily: Fonts.bold, fontSize: 32, letterSpacing: -0.8, color: C.t1 },
    header:         { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 18, paddingBottom: 12 },
    pillTrack:      { flex: 1, flexDirection: 'row', position: 'relative', backgroundColor: C.border, borderRadius: 999, padding: 3, height: 42 },
    pillActive:     { position: 'absolute', top: 3, bottom: 3, left: 3, backgroundColor: C.card, borderRadius: 999, shadowColor: '#000', shadowOpacity: 0.06, shadowRadius: 4, shadowOffset: { width: 0, height: 1 }, elevation: 1 },
    tabItem:        { flex: 1, alignItems: 'center', justifyContent: 'center', zIndex: 1 },
    tabLabel:       { fontFamily: Fonts.medium, fontSize: 14, color: C.t2 },
    tabLabelActive: { fontFamily: Fonts.semiBold, color: C.t1 },
    searchIcon:     { width: 42, height: 42, borderRadius: 21, backgroundColor: C.card, alignItems: 'center', justifyContent: 'center' },
    list:           { paddingTop: 4, paddingBottom: 100 },
    // Suggested runners
    suggestedSection: { backgroundColor: C.card, marginHorizontal: 12, marginBottom: 12, borderRadius: 22, paddingTop: 16, paddingBottom: 14 },
    suggestedLabel:   { color: C.t2, paddingHorizontal: 16, marginBottom: 14 },
    suggestedScroll:  { paddingHorizontal: 16, gap: 12 },
    runnerCard:       { alignItems: 'center', gap: 5, minWidth: 68 },
    runnerAvatarWrap: { position: 'relative' },
    followDot:        { position: 'absolute', bottom: -1, right: -1, width: 20, height: 20, borderRadius: 10, backgroundColor: C.red, borderWidth: 2, borderColor: C.card, alignItems: 'center', justifyContent: 'center' },
    runnerName:       { fontFamily: Fonts.semiBold, fontSize: 12, color: C.t1, textAlign: 'center' },
    runnerScore:      { fontFamily: Fonts.numeric, fontSize: 14, color: C.t2, textAlign: 'center', marginTop: -2 },
    // Search modal
    searchModal:  { flex: 1, backgroundColor: C.bg },
    searchHeader: { flexDirection: 'row', alignItems: 'center', gap: 10, paddingHorizontal: Spacing.gutter, paddingVertical: 12, borderBottomWidth: 0.5, borderBottomColor: C.border },
    searchInput:  { flex: 1, fontFamily: Fonts.regular, fontSize: 15, color: C.t1, height: 42, backgroundColor: C.card, borderRadius: 999, paddingHorizontal: 16 },
    searchEmpty:  { fontFamily: Fonts.regular, fontSize: 13, color: C.t3, textAlign: 'center', paddingTop: 40, paddingHorizontal: 32 },
  });
}
