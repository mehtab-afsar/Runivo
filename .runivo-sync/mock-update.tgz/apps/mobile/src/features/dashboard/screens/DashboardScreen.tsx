import React, { useState, useCallback, useMemo, useEffect, useRef } from 'react';
import { View, Text, ScrollView, Pressable, StyleSheet, ActivityIndicator, RefreshControl } from 'react-native';
import { fetchUnreadCount } from '@features/notifications/services/notificationsService';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useNavigation, useFocusEffect } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import * as Haptics from 'expo-haptics';
import { ArrowRight, Bell, Play, Shield, Users, CalendarDays, Sparkles, Gift } from 'lucide-react-native';
import { useLiveFriendRuns } from '@features/run/hooks/useLiveFriendRuns';
import { useGpsStatus } from '../hooks/useGpsStatus';

import type { RootStackParamList } from '@navigation/AppNavigator';
import { useTheme, Type, Fonts, Spacing, type AppColors } from '@theme';
import { Avatar } from '@mobile/shared/components/Avatar';
import { FEATURES } from '../../../config/features';
import { useDashboard } from '../hooks/useDashboard';
import { MiniTerritoryMap } from '../components/MiniTerritoryMap';
import { MissionRow } from '../components/MissionRow';
import { RecentRunRow } from '../components/RecentRunRow';
import { DailyBonusCard } from '../components/DailyBonusCard';
import { TerritoryCapBanner } from '../components/TerritoryCapBanner';
import { CommunityPulseCard } from '../components/CommunityPulseCard';
import { DashboardTour } from '../components/DashboardTour';
import { useFeatureGate } from '@features/subscription/hooks/useFeatureGate';

type Nav = NativeStackNavigationProp<RootStackParamList>;

export default function DashboardScreen() {
  const C = useTheme();
  const s = useMemo(() => mkStyles(C), [C]);
  const insets     = useSafeAreaInsets();
  const navigation = useNavigation<Nav>();
  const dash       = useDashboard();
  const gate       = useFeatureGate();
  const liveFriends = useLiveFriendRuns();
  const gps        = useGpsStatus();
  const [unreadCount, setUnreadCount] = useState(0);
  const [tsDisplay, setTsDisplay]     = useState(0);
  const hasAnimatedTs                 = useRef(false);
  const paceStoreRef = useRef<View>(null);
  const bentoRef     = useRef<View>(null);
  const mapRef       = useRef<View>(null);

  useEffect(() => {
    if (dash.territoryScore > 0 && !hasAnimatedTs.current) {
      hasAnimatedTs.current = true;
      const target = dash.territoryScore;
      const startTime = Date.now();
      const id = setInterval(() => {
        const elapsed = Date.now() - startTime;
        const t = Math.min(1, elapsed / 800);
        const eased = 1 - Math.pow(1 - t, 3);
        setTsDisplay(Math.round(eased * target));
        if (t >= 1) clearInterval(id);
      }, 16);
      return () => clearInterval(id);
    }
  }, [dash.territoryScore]);

  useFocusEffect(
    useCallback(() => {
      fetchUnreadCount().then(setUnreadCount).catch(err => {
        if (__DEV__) console.error('[Notifications] fetchUnreadCount:', err);
      });
    }, []),
  );

  type GoScreen = 'Notifications' | 'Missions' | 'History';
  const go = (screen: GoScreen) => { Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light); navigation.navigate(screen); };

  if (dash.loading || !dash.player) {
    return <View style={[s.fill, { backgroundColor: C.bg, alignItems: 'center', justifyContent: 'center' }]}><Text style={s.loadText}>runivo</Text></View>;
  }

  const now = new Date();
  const h = now.getHours();
  const greeting = h < 5 ? 'Good night' : h < 12 ? 'Morning' : h < 17 ? 'Afternoon' : h < 21 ? 'Evening' : 'Good night';
  const firstName = (dash.player.username || '').split(/[._\s]/)[0] || dash.player.username;
  const dateLine = now.toLocaleDateString('en-GB', { weekday: 'short', day: 'numeric', month: 'short' });
  const streakDays = dash.player.streakDays || 0;
  const weeklyEarned = dash.player.paceWeeklyEarned ?? 0;
  const weeklyCap = dash.weeklyCapLimit || 100;
  const capPct = Math.min(100, Math.round((weeklyEarned / weeklyCap) * 100));
  const maxDayKm = Math.max(1, ...dash.dayKm);
  const todayIdx = (now.getDay() + 6) % 7; // Monday = 0
  const tap = () => Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);

  const quick: { key: string; label: string; Icon: typeof Users; onPress: () => void; accent?: boolean }[] = [
    { key: 'clubs', label: 'Clubs', Icon: Users, onPress: () => { tap(); navigation.navigate('Club'); } },
    ...(FEATURES.EVENTS ? [{ key: 'events', label: 'Events', Icon: CalendarDays, onPress: () => { tap(); navigation.navigate('Events'); } }] : []),
    ...(FEATURES.AI_COACH ? [{ key: 'pacex', label: 'PaceX', Icon: Sparkles, accent: true, onPress: () => { tap(); navigation.navigate('Coach'); } }] : []),
    { key: 'store', label: 'Store', Icon: Gift, onPress: () => { tap(); navigation.navigate('PACEStore'); } },
  ];

  return (
    <View style={[s.fill, { backgroundColor: C.bg }]}>
      {dash.loginBonusCoins > 0 && (
        <View style={[s.bonusToastWrap, { top: insets.top + 8 }]}>
          <DailyBonusCard coins={dash.loginBonusCoins} onCollect={dash.dismissLoginBonus} />
        </View>
      )}

      <ScrollView
        style={s.fill}
        contentContainerStyle={{ paddingBottom: 110, paddingTop: insets.top + 8, paddingHorizontal: Spacing.gutter, gap: 12 }}
        showsVerticalScrollIndicator={false}
        refreshControl={<RefreshControl refreshing={dash.refreshing} onRefresh={dash.refresh} tintColor={C.t3} />}
      >
        {/* Header */}
        <View style={s.header}>
          <View style={{ flex: 1 }}>
            <Text style={s.dateLine}>{dateLine}</Text>
            <Text style={s.hello} numberOfLines={1}>{greeting}, {firstName}</Text>
          </View>
          <Pressable onPress={() => { go('Notifications'); setUnreadCount(0); }} style={s.iconBtn} hitSlop={6} accessibilityLabel="Notifications">
            <Bell size={17} color={C.t1} strokeWidth={1.8} />
            {unreadCount > 0 && <View style={s.dot} />}
          </Pressable>
          <Pressable onPress={() => navigation.navigate('Main', { screen: 'Profile' })} hitSlop={4} accessibilityLabel="Your profile">
            <Avatar uri={dash.avatarUrl} name={dash.player.username} size={38} />
          </Pressable>
        </View>

        {dash.syncError && (
          <Pressable style={s.syncChip} onPress={() => dash.refresh()}>
            {dash.refreshing && <ActivityIndicator size="small" color={C.alwaysLight} />}
            <Text style={s.syncText}>{dash.refreshing ? 'Syncing…' : 'Sync failed. Tap to retry'}</Text>
          </Pressable>
        )}

        {/* Territory score */}
        <Pressable style={s.card} onPress={() => { tap(); navigation.navigate('Leaderboard'); }}>
          <Text style={s.label}>Territory score</Text>
          <View style={s.scoreRow}>
            <Text style={s.scoreNum} numberOfLines={1} adjustsFontSizeToFit>{tsDisplay.toLocaleString()}</Text>
            {dash.cityRank != null && (
              <View style={s.rankBlock}>
                <Text style={s.rankNum}>#{dash.cityRank}</Text>
                <Text style={s.rankWhere}>near you</Text>
              </View>
            )}
            <ArrowRight size={20} color={C.t3} strokeWidth={1.8} style={s.scoreArrow} />
          </View>
          <View style={s.statRow}>
            <View style={s.stat}>
              <Text style={s.statNum}>{dash.ownedCount}{!gate.isPremium && <Text style={s.statOf}> / {gate.territoryLimit}</Text>}</Text>
              <Text style={s.statLabel}>Zones held</Text>
            </View>
            <View style={[s.stat, s.statDivider]}>
              <Text style={[s.statNum, dash.staleCount > 0 && { color: C.red }]}>{dash.staleCount}</Text>
              <Text style={s.statLabel}>Fading</Text>
            </View>
            <View style={[s.stat, s.statDivider]}>
              <Text style={s.statNum}>{streakDays}<Text style={s.statOf}> {streakDays === 1 ? 'day' : 'days'}</Text></Text>
              <Text style={s.statLabel}>Streak</Text>
            </View>
          </View>
        </Pressable>

        {/* Start run */}
        <Pressable
          style={({ pressed }) => [s.startBtn, pressed && { opacity: 0.9, transform: [{ scale: 0.99 }] }]}
          onPress={() => { Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium); navigation.navigate('Main', { screen: 'Run' }); }}
          accessibilityRole="button"
        >
          <View style={s.rowCenter}>
            <Play size={16} color="#fff" fill="#fff" />
            <Text style={s.startText}>{dash.hasRunToday ? 'Run again' : 'Start run'}</Text>
          </View>
          <View style={s.startChip}>
            {gps === 'ready' && <View style={s.gpsDot} />}
            <Text style={s.startChipText}>
              {gps === 'ready' ? 'GPS ready' : gps === 'off' ? 'Location off' : 'Finding GPS…'}
            </Text>
          </View>
        </Pressable>

        {/* Friends running now */}
        {liveFriends.length > 0 && (
          <Pressable style={[s.card, s.liveCard]} onPress={() => { tap(); navigation.navigate('Main', { screen: 'Map' }); }}>
            <View style={s.liveAvatars}>
              {liveFriends.slice(0, 3).map((f, i) => (
                <View key={f.userId} style={[s.liveAvatarRing, i > 0 && { marginLeft: -12 }]}>
                  <Avatar name={f.username} color={f.avatarColor} size={40} />
                </View>
              ))}
            </View>
            <View style={{ flex: 1 }}>
              <Text style={s.liveTitle}>
                {liveFriends.length === 1 ? '1 friend running now' : `${liveFriends.length} friends running now`}
              </Text>
              <Text style={s.alertSub} numberOfLines={1}>
                {liveFriends.length === 1 ? `${liveFriends[0].username} is out now` : `${liveFriends[0].username} and ${liveFriends.length - 1} more`}
              </Text>
            </View>
            <View style={s.liveChip}><View style={s.liveDot} /><Text style={s.liveChipText}>Live</Text></View>
          </Pressable>
        )}

        {/* Fading zones */}
        {dash.staleCount > 0 && (
          <View style={[s.card, s.alertCard]}>
            <View style={s.alertIcon}><Shield size={18} color="#fff" strokeWidth={2} /></View>
            <View style={{ flex: 1 }}>
              <Text style={s.alertTitle}>{dash.staleCount === 1 ? 'A zone is fading' : `${dash.staleCount} zones are fading`}</Text>
              <Text style={s.alertSub}>{dash.lowestFreshness}% fresh · run through {dash.staleCount === 1 ? 'it' : 'them'} to defend</Text>
            </View>
            <Pressable style={s.inkPill} onPress={() => { tap(); navigation.navigate('TerritoryMap', { initialFilter: 'stale' }); }}>
              <Text style={s.inkPillText}>Defend</Text>
            </Pressable>
          </View>
        )}

        {!gate.loading && !gate.canClaimTerritory(dash.ownedCount) && (
          <TerritoryCapBanner
            ownedCount={dash.ownedCount}
            territoryLimit={gate.territoryLimit}
            onUpgrade={() => { Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium); navigation.navigate('Subscription', { reason: 'zone_limit' }); }}
          />
        )}

        {/* Quick actions */}
        <View style={s.quickRow}>
          {quick.map(q => (
            <Pressable key={q.key} style={({ pressed }) => [s.quick, pressed && { opacity: 0.8 }]} onPress={q.onPress}>
              <q.Icon size={20} color={q.accent ? C.red : C.t1} strokeWidth={1.8} />
              <Text style={s.quickText}>{q.label}</Text>
            </Pressable>
          ))}
        </View>

        {/* PACE this week */}
        <View ref={paceStoreRef} collapsable={false}>
          <Pressable style={s.card} onPress={() => { Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium); navigation.navigate('PACEStore'); }}>
            <View style={s.rowBetween}>
              <Text style={s.label}>PACE this week</Text>
              <Text style={s.label}><Text style={s.inlineNum}>{weeklyEarned}</Text> / {weeklyCap} cap</Text>
            </View>
            <View style={s.track}><View style={[s.fillBar, { width: `${capPct}%`, backgroundColor: C.red }]} /></View>
            <View style={s.rowBetween}>
              <Text style={s.small}>{(dash.player.paceBalance ?? 0).toLocaleString()} PACE to spend</Text>
              <View style={s.rowCenterTight}>
                <Text style={s.smallStrong}>PACE Store</Text>
                <ArrowRight size={14} color={C.t1} strokeWidth={2} />
              </View>
            </View>
          </Pressable>
        </View>

        {/* This week */}
        <View ref={bentoRef} collapsable={false} style={s.card}>
          <View style={s.rowBetween}>
            <Text style={s.label}>This week</Text>
            <Text style={s.label}><Text style={s.inlineNum}>{dash.weeklyKm.toFixed(1)}</Text> / {dash.weeklyGoal} km</Text>
          </View>
          <View style={s.bars}>
            {['M', 'T', 'W', 'T', 'F', 'S', 'S'].map((d, i) => {
              const km = dash.dayKm[i] ?? 0;
              const today = i === todayIdx;
              const future = i > todayIdx;
              const h = km > 0 ? Math.max(10, Math.round((km / maxDayKm) * BAR_H)) : 0;
              return (
                <View key={i} style={s.barCol}>
                  <View style={s.barSlot}>
                    {km > 0 ? (
                      <View style={[s.bar, { height: h }]} />
                    ) : today || future ? (
                      <View style={[s.barEmpty, today && { borderColor: C.red }]} />
                    ) : (
                      <View style={s.barNone} />
                    )}
                  </View>
                  <Text style={[s.dayLabel, today && { color: C.red, fontFamily: Fonts.semiBold }]}>{d}</Text>
                </View>
              );
            })}
          </View>
        </View>

        {/* Missions */}
        <View style={s.card}>
          <View style={[s.rowBetween, { marginBottom: 12 }]}>
            <Text style={s.label}>Today's missions · {dash.missions.length}</Text>
            <Pressable onPress={() => go('Missions')} hitSlop={8}><Text style={s.label}>Resets at midnight</Text></Pressable>
          </View>
          {dash.missions.map((m, i) => (
            <MissionRow key={m.id} mission={m} isLast={i === dash.missions.length - 1} onClaim={dash.claimMission} />
          ))}
        </View>

        {/* Map */}
        <View ref={mapRef} collapsable={false}>
          <MiniTerritoryMap territories={dash.territories} ownerId={dash.player.id} onPress={() => navigation.navigate('TerritoryMap')} />
        </View>

        {/* Recent runs */}
        {dash.recentRuns.length > 0 && (
          <View>
            <View style={[s.rowBetween, { marginBottom: 8, marginTop: 4 }]}>
              <Text style={s.sectionTitle}>Recent runs</Text>
              <Pressable onPress={() => go('History')} hitSlop={8}><Text style={s.smallStrong}>See all</Text></Pressable>
            </View>
            <View style={[s.card, { padding: 0, overflow: 'hidden' }]}>
              {dash.recentRuns.map((r, i) => (
                <RecentRunRow key={r.id} run={r} isLast={i === dash.recentRuns.length - 1} onPress={run => navigation.navigate('RunSummary', { runId: run.id })} />
              ))}
            </View>
          </View>
        )}

        <CommunityPulseCard
          onOpenRoom={lobbyId => navigation.navigate('LobbyChat', { lobbyId })}
          onOpenDiscover={() => navigation.navigate('Main', { screen: 'Feed' })}
        />
      </ScrollView>

      <DashboardTour targets={{ paceStore: paceStoreRef, bento: bentoRef, map: mapRef }} active={dash.recentRuns.length === 0} />
    </View>
  );
}

const BAR_H = 64;

function mkStyles(C: AppColors) {
  const card = {
    backgroundColor: C.card, borderRadius: 16, padding: 16,
    shadowColor: '#14120F', shadowOpacity: 0.05, shadowRadius: 3, shadowOffset: { width: 0, height: 1 }, elevation: 1,
  } as const;
  return StyleSheet.create({
    fill:           { flex: 1 },
    bonusToastWrap: { position: 'absolute', left: 0, right: 0, zIndex: 50 },
    loadText:       { fontFamily: Fonts.wordmark, fontSize: 26, letterSpacing: -0.5, color: C.t1 },

    header:      { flexDirection: 'row', alignItems: 'center', gap: 10, marginBottom: 4 },
    dateLine:    { ...Type.labelSm, color: C.t2 },
    hello:       { fontFamily: Fonts.bold, fontSize: 26, letterSpacing: -0.7, color: C.t1, marginTop: 2 },
    iconBtn:     { width: 38, height: 38, borderRadius: 19, backgroundColor: C.card, alignItems: 'center', justifyContent: 'center' },
    dot:         { position: 'absolute', top: 8, right: 9, width: 8, height: 8, borderRadius: 4, backgroundColor: C.red, borderWidth: 1.5, borderColor: C.card },

    card,
    rowBetween:  { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
    rowCenter:   { flexDirection: 'row', alignItems: 'center', gap: 10 },
    label:       { ...Type.label, color: C.t2 },
    small:       { ...Type.labelSm, color: C.t2 },
    smallStrong: { ...Type.labelSm, fontFamily: Fonts.semiBold, color: C.t1 },
    sectionTitle:{ fontFamily: Fonts.bold, fontSize: 17, letterSpacing: -0.3, color: C.t1 },
    inlineNum:   { fontFamily: Fonts.numeric, fontSize: 18, color: C.t1 },
    rowCenterTight: { flexDirection: 'row', alignItems: 'center', gap: 4 },
    rankBlock:   { paddingBottom: 12, marginLeft: 10 },
    rankNum:     { ...Type.label, fontFamily: Fonts.semiBold, color: C.t1 },
    rankWhere:   { ...Type.label, color: C.t2 },
    scoreArrow:  { marginLeft: 'auto', marginBottom: 16 },

    scoreRow:    { flexDirection: 'row', alignItems: 'flex-end', marginTop: 8 },
    scoreNum:    { fontFamily: Fonts.numeric, fontSize: 88, lineHeight: 86, letterSpacing: -1, color: C.t1, fontVariant: ['tabular-nums'], flexShrink: 1 },
    statRow:     { flexDirection: 'row', marginTop: 12, paddingTop: 12, borderTopWidth: 0.5, borderTopColor: C.border },
    stat:        { flex: 1 },
    statDivider: { borderLeftWidth: 0.5, borderLeftColor: C.border, paddingLeft: 14 },
    statNum:     { fontFamily: Fonts.numeric, fontSize: 26, color: C.t1, fontVariant: ['tabular-nums'] },
    statOf:      { fontFamily: Fonts.numeric, fontSize: 16, color: C.t3 },
    statLabel:   { ...Type.labelSm, color: C.t2, marginTop: 2 },

    startBtn:    { height: 60, borderRadius: 30, backgroundColor: C.red, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingLeft: 24, paddingRight: 8 },
    startText:   { fontFamily: Fonts.semiBold, fontSize: 17, color: '#fff' },
    startChip:   { height: 44, borderRadius: 22, paddingHorizontal: 16, backgroundColor: 'rgba(255,255,255,0.2)', flexDirection: 'row', alignItems: 'center', gap: 7 },
    startChipText:{ ...Type.labelSm, fontFamily: Fonts.semiBold, color: '#fff' },
    gpsDot:      { width: 7, height: 7, borderRadius: 4, backgroundColor: '#fff' },

    liveCard:    { flexDirection: 'row', alignItems: 'center', gap: 12 },
    liveAvatars: { flexDirection: 'row' },
    liveAvatarRing: { borderWidth: 2.5, borderColor: C.green, borderRadius: 24 },
    liveTitle:   { ...Type.headline, color: C.t1 },
    liveChip:    { flexDirection: 'row', alignItems: 'center', gap: 5, backgroundColor: C.greenBg, borderRadius: 8, paddingHorizontal: 8, paddingVertical: 4 },
    liveDot:     { width: 6, height: 6, borderRadius: 3, backgroundColor: C.green },
    liveChipText:{ ...Type.labelSm, fontFamily: Fonts.semiBold, color: C.green },

    alertCard:   { flexDirection: 'row', alignItems: 'center', gap: 12, backgroundColor: C.redLo, borderWidth: 1, borderColor: 'rgba(255,69,24,0.25)', shadowOpacity: 0 },
    alertIcon:   { width: 40, height: 40, borderRadius: 12, backgroundColor: C.blue, alignItems: 'center', justifyContent: 'center' },
    alertTitle:  { ...Type.headline, color: C.t1 },
    alertSub:    { ...Type.labelSm, color: C.t2, marginTop: 2 },
    inkPill:     { height: 34, paddingHorizontal: 14, borderRadius: 17, backgroundColor: C.alwaysDark, justifyContent: 'center' },
    inkPillText: { ...Type.labelSm, fontFamily: Fonts.semiBold, color: '#fff' },

    quickRow:    { flexDirection: 'row', gap: 8 },
    quick:       { ...card, flex: 1, padding: 12, alignItems: 'center', gap: 6 },
    quickText:   { ...Type.labelSm, fontFamily: Fonts.semiBold, color: C.t1 },

    track:       { height: 8, borderRadius: 4, backgroundColor: C.surface, overflow: 'hidden', marginVertical: 10 },
    fillBar:     { height: 8, borderRadius: 4 },
    bars:        { flexDirection: 'row', justifyContent: 'space-between', gap: 8, marginTop: 14 },
    barCol:      { flex: 1, alignItems: 'center', gap: 8 },
    barSlot:     { height: BAR_H, width: '100%', justifyContent: 'flex-end' },
    bar:         { width: '100%', borderRadius: 7, backgroundColor: C.t1 },
    barEmpty:    { height: BAR_H, width: '100%', borderRadius: 7, borderWidth: 1.5, borderStyle: 'dashed', borderColor: C.border },
    barNone:     { height: 3, width: '100%', borderRadius: 2, backgroundColor: C.border },
    dayLabel:    { ...Type.labelSm, color: C.t2 },

    syncChip:    { flexDirection: 'row', alignItems: 'center', alignSelf: 'center', gap: 6, backgroundColor: C.red, borderRadius: 16, paddingHorizontal: 12, paddingVertical: 6 },
    syncText:    { ...Type.labelSm, color: C.alwaysLight },
  });
}
