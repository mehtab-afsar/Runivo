import React, { useCallback, useMemo, useState } from 'react';
import { View, Text, ScrollView, Pressable, StyleSheet } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useFocusEffect, useNavigation } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { X } from 'lucide-react-native';
import { useTheme, Type, Fonts, Spacing, type AppColors } from '@theme';
import * as Haptics from 'expo-haptics';
import { usePACEStore } from '../hooks/usePACEStore';
import { RewardCard } from '../components/RewardCard';
import { RewardTile } from '../components/RewardTile';
import type { Reward } from '../types';
import type { RootStackParamList } from '@navigation/AppNavigator';

type Nav = NativeStackNavigationProp<RootStackParamList>;

/** Store chips, in the mock's order. Only categories that have rewards are shown. */
const CATEGORY_CHIPS: { key: Reward['category']; label: string }[] = [
  { key: 'gear',      label: 'Gear' },
  { key: 'nutrition', label: 'Fuel' },
  { key: 'events',    label: 'Races' },
  { key: 'tech',      label: 'Tech' },
];

export default function PACEStoreScreen() {
  const C = useTheme();
  const s = useMemo(() => mkStyles(C), [C]);
  const insets = useSafeAreaInsets();
  const navigation = useNavigation<Nav>();
  const { paceBalance, paceWeeklyEarned, capLimit, weeklyPct, runnerRank, rewards, refresh } = usePACEStore();
  // Back from a reward: pick up its new state (redeemed, code, stock left).
  useFocusEffect(useCallback(() => { refresh(); }, [refresh]));

  const [category, setCategory] = useState<Reward['category'] | 'all'>('all');
  const chips = useMemo(
    () => CATEGORY_CHIPS.filter(c => rewards.some(r => r.category === c.key)),
    [rewards],
  );
  const shown = category === 'all' ? rewards : rewards.filter(r => r.category === category);
  const [featured, ...rest] = shown;
  const displayRank = runnerRank.charAt(0).toUpperCase() + runnerRank.slice(1);

  const open = (reward: Reward) => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light).catch(() => {});
    navigation.navigate('RewardDetail', { rewardId: reward.id, reward });
  };

  return (
    <View style={[s.root, { paddingTop: insets.top }]}>
      <View style={s.headerBar}>
        <Pressable onPress={() => navigation.goBack()} hitSlop={10} style={s.closeBtn} accessibilityLabel="Close">
          <X size={18} color={C.t1} strokeWidth={2.2} />
        </Pressable>
        <View style={s.rankChip}>
          <Text style={s.rankChipText}>{displayRank}</Text>
        </View>
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: insets.bottom + 40 }}>
        {/* Balance */}
        <View style={s.balanceBlock}>
          <Text style={s.eyebrow}>PACE Store</Text>
          <View style={s.balanceRow}>
            <Text style={s.balanceNum} adjustsFontSizeToFit numberOfLines={1}>{paceBalance.toLocaleString()}</Text>
            <Text style={s.balanceUnit}>PACE</Text>
          </View>
        </View>

        {/* Earned this week */}
        <View style={s.weekCard}>
          <View style={s.weekRow}>
            <Text style={s.weekLabel}>Earned this week</Text>
            <Text style={s.weekNumbers}>
              <Text style={s.weekStrong}>{paceWeeklyEarned}</Text> / {capLimit} · resets Monday
            </Text>
          </View>
          <View style={s.progressBarBg}>
            <View style={[s.progressBarFill, { width: `${Math.round(weeklyPct * 100)}%` }]} />
          </View>
        </View>

        {/* Categories */}
        {chips.length > 1 && (
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={s.chips}>
            {[{ key: 'all' as const, label: 'All' }, ...chips].map(c => {
              const active = category === c.key;
              return (
                <Pressable
                  key={c.key}
                  onPress={() => setCategory(c.key)}
                  style={[s.chip, active && s.chipActive]}
                  accessibilityRole="button"
                  accessibilityState={{ selected: active }}
                >
                  <Text style={[s.chipText, active && s.chipTextActive]}>{c.label}</Text>
                </Pressable>
              );
            })}
          </ScrollView>
        )}

        {/* Featured + grid */}
        {featured && (
          <View style={s.section}>
            <RewardCard reward={featured} onPress={open} />
          </View>
        )}
        {rest.length > 0 && (
          <View style={s.grid}>
            {rest.map(r => (
              <View key={r.id} style={s.gridCell}>
                <RewardTile reward={r} onPress={open} />
              </View>
            ))}
          </View>
        )}

        {/* How you earn PACE */}
        <View style={s.howCard}>
          <Text style={s.howTitle}>How you earn PACE</Text>
          <HowRow label="Every km you run" value="+1" color={C.t1} styles={s} />
          <HowRow label="Claim a new zone" value="+5" color={C.red} styles={s} />
          <HowRow label="Steal a rival's zone" value="+10" color={C.blue} styles={s} />
          <HowRow label="Keep your streak" value="+3" color={C.t1} styles={s} last />
        </View>
      </ScrollView>
    </View>
  );
}

function HowRow({ label, value, color, styles: s, last }: {
  label: string; value: string; color: string; styles: ReturnType<typeof mkStyles>; last?: boolean;
}) {
  return (
    <View style={[s.howRow, !last && s.howRowBorder]}>
      <Text style={s.howLabel}>{label}</Text>
      <Text style={[s.howValue, { color }]}>{value}</Text>
    </View>
  );
}

function mkStyles(C: AppColors) {
  const card = {
    backgroundColor: C.card, borderRadius: Spacing.radius.lg,
    shadowColor: C.t1, shadowOpacity: 0.05, shadowRadius: 12, shadowOffset: { width: 0, height: 4 }, elevation: 1,
  } as const;
  return StyleSheet.create({
    root:            { flex: 1, backgroundColor: C.bg },
    headerBar:       { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: Spacing.gutter, paddingVertical: 10 },
    closeBtn:        { width: 40, height: 40, borderRadius: 20, alignItems: 'center', justifyContent: 'center', backgroundColor: C.card },
    rankChip:        { backgroundColor: C.t1, borderRadius: 8, paddingHorizontal: 10, paddingVertical: 5 },
    rankChipText:    { fontFamily: Fonts.semiBold, fontSize: 12, color: C.bg },
    balanceBlock:    { paddingHorizontal: Spacing.gutter, marginTop: 8, marginBottom: 14 },
    eyebrow:         { ...Type.label, color: C.t2 },
    balanceRow:      { flexDirection: 'row', alignItems: 'flex-end', gap: 8, marginTop: 2 },
    balanceNum:      { fontFamily: Fonts.numeric, fontSize: 84, lineHeight: 86, color: C.t1, fontVariant: ['tabular-nums'], flexShrink: 1 },
    balanceUnit:     { fontFamily: Fonts.bold, fontSize: 22, color: C.red, paddingBottom: 12 },
    weekCard:        { ...card, paddingHorizontal: 16, paddingVertical: 14, marginHorizontal: Spacing.gutter, marginBottom: 14 },
    weekRow:         { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 },
    weekLabel:       { ...Type.bodySm, color: C.t2 },
    weekNumbers:     { fontFamily: Fonts.regular, fontSize: 13, color: C.t2, fontVariant: ['tabular-nums'] },
    weekStrong:      { fontFamily: Fonts.bold, color: C.t1 },
    progressBarBg:   { height: 8, backgroundColor: C.border, borderRadius: 4, overflow: 'hidden' },
    progressBarFill: { height: 8, backgroundColor: C.red, borderRadius: 4 },
    chips:           { paddingHorizontal: Spacing.gutter, gap: 8, marginBottom: 14 },
    chip:            { height: 34, paddingHorizontal: 14, borderRadius: 999, backgroundColor: C.card, alignItems: 'center', justifyContent: 'center' },
    chipActive:      { backgroundColor: C.t1 },
    chipText:        { fontFamily: Fonts.semiBold, fontSize: 13, color: C.t1 },
    chipTextActive:  { color: C.bg },
    section:         { paddingHorizontal: Spacing.gutter, marginBottom: 12 },
    grid:            { flexDirection: 'row', flexWrap: 'wrap', paddingHorizontal: Spacing.gutter - 6, marginBottom: 6 },
    gridCell:        { width: '50%', paddingHorizontal: 6, marginBottom: 12 },
    howCard:         { ...card, marginHorizontal: Spacing.gutter, paddingHorizontal: 16, paddingTop: 14, paddingBottom: 4 },
    howTitle:        { ...Type.label, color: C.t2, marginBottom: 4 },
    howRow:          { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingVertical: 12 },
    howRowBorder:    { borderBottomWidth: 1, borderBottomColor: C.border },
    howLabel:        { fontFamily: Fonts.medium, fontSize: 15, color: C.t1 },
    howValue:        { fontFamily: Fonts.numeric, fontSize: 22, lineHeight: 24, fontVariant: ['tabular-nums'] },
  });
}
