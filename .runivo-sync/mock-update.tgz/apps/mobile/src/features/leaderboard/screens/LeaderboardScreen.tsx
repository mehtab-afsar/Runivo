import React, { useMemo, useCallback, useEffect } from 'react';
import { View, Text, StyleSheet, FlatList, Pressable, SafeAreaView, Platform } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import type { RootStackParamList } from '@navigation/AppNavigator';
import Animated, { useSharedValue, useAnimatedStyle, withRepeat, withTiming, Easing } from 'react-native-reanimated';
import { useLeaderboard } from '../hooks/useLeaderboard';
import { EntryRow, splitValue } from '../components/EntryRow';
import { LeaderboardFilters } from '../components/LeaderboardFilters';
import type { LeaderboardEntry } from '../types';
import { avatarColor } from '@shared/lib/avatarUtils';
import { ArrowLeft } from 'phosphor-react-native';
import { useTheme, Fonts, type AppColors } from '@theme';

type Nav = NativeStackNavigationProp<RootStackParamList>;

// Module-level for a stable identity across renders.
const keyExtractor = (e: LeaderboardEntry) => String(e.rank);

// Podium: No.2 · No.1 (black, taller) · No.3 as cards, like the mock.
function Podium({ entries, unit }: { entries: LeaderboardEntry[]; unit: string }) {
  const C = useTheme();
  const ps = useMemo(() => mkPsStyles(C), [C]);
  if (entries.length < 3) return null;
  const order = [entries[1], entries[0], entries[2]];

  return (
    <View style={ps.wrap}>
      {order.map((entry, i) => {
        const v = splitValue(entry.value, unit);
        const first = i === 1;
        const size = first ? 58 : 48;
        return (
          <View key={entry.rank} style={[ps.card, first ? ps.cardFirst : ps.cardSide]}>
            <View style={[ps.ring, first && { borderColor: C.red }, { width: size + 8, height: size + 8, borderRadius: (size + 8) / 2 }]}>
              <View style={[ps.avatar, { width: size, height: size, borderRadius: size / 2, backgroundColor: avatarColor(entry.name) }]}>
                <Text style={[ps.avatarText, { fontSize: size * 0.4 }]}>{entry.name.slice(0, 1).toUpperCase()}</Text>
              </View>
            </View>
            <Text style={[ps.name, first && ps.nameFirst]} numberOfLines={1}>{entry.isPlayer ? 'You' : entry.name}</Text>
            <Text style={[ps.val, first && ps.valFirst]} numberOfLines={1} adjustsFontSizeToFit>
              {v.num}{unit !== 'TS' ? <Text style={[ps.valUnit, first && ps.valUnitFirst]}> {v.suffix}</Text> : null}
            </Text>
            <Text style={[ps.rankLabel, first && ps.rankLabelFirst]}>No. {entry.rank}</Text>
          </View>
        );
      })}
    </View>
  );
}

// Shimmering placeholder rows shown while the board loads — replaces the bare
// centered spinner, matching the row shape so the swap-in doesn't jump.
function SkeletonRows() {
  const C = useTheme();
  const s = useMemo(() => mkStyles(C), [C]);
  const pulse = useSharedValue(0.4);

  useEffect(() => {
    pulse.value = withRepeat(withTiming(1, { duration: 700, easing: Easing.inOut(Easing.quad) }), -1, true);
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const pulseStyle = useAnimatedStyle(() => ({ opacity: pulse.value }));

  return (
    <View style={s.skeletonWrap}>
      {Array.from({ length: 7 }).map((_, i) => (
        <Animated.View key={i} style={[s.skeletonRow, pulseStyle, { backgroundColor: C.surface }]} />
      ))}
    </View>
  );
}

function mkPsStyles(C: AppColors) {
  return StyleSheet.create({
    wrap:          { flexDirection: 'row', alignItems: 'flex-end', paddingHorizontal: 18, paddingBottom: 14, gap: 8 },
    card:          { flex: 1, alignItems: 'center', borderRadius: 22, paddingHorizontal: 8 },
    cardSide:      { backgroundColor: C.card, paddingTop: 18, paddingBottom: 16 },
    cardFirst:     { backgroundColor: C.alwaysDark, paddingTop: 26, paddingBottom: 20, flex: 1.12 },
    ring:          { borderWidth: 3, borderColor: 'transparent', alignItems: 'center', justifyContent: 'center', marginBottom: 8 },
    avatar:        { alignItems: 'center', justifyContent: 'center' },
    avatarText:    { fontFamily: Fonts.semiBold, color: C.alwaysLight },
    name:          { fontFamily: Fonts.semiBold, fontSize: 13, color: C.t1 },
    nameFirst:     { color: C.alwaysLight },
    val:           { fontFamily: Fonts.numeric, fontSize: 26, lineHeight: 30, color: C.t1, marginTop: 2, fontVariant: ['tabular-nums'] },
    valFirst:      { fontSize: 32, lineHeight: 36, color: C.alwaysLight },
    valUnit:       { fontFamily: Fonts.medium, fontSize: 11, color: C.t2 },
    valUnitFirst:  { color: 'rgba(255,255,255,0.6)' },
    rankLabel:     { fontFamily: Fonts.medium, fontSize: 12, color: C.t2, marginTop: 2 },
    rankLabelFirst:{ color: C.red },
  });
}

export default function LeaderboardScreen() {
  const C = useTheme();
  const s = useMemo(() => mkStyles(C), [C]);
  const navigation = useNavigation<Nav>();
  const { entries, loading, tab, timeFrame, scope, unit, currentUserId, setTab, setTimeFrame, setScope } = useLeaderboard();

  // Current player's entry (for sticky footer if rank > 3)
  const playerEntry = entries.find(e => e.isPlayer);
  const playerOutsideTop3 = playerEntry && playerEntry.rank > 3;
  const playerVal = playerEntry ? splitValue(playerEntry.value, unit) : null;
  // "380 behind No. 13" — only when the runner above is on the loaded page.
  const above = playerEntry ? entries.find(e => e.rank === playerEntry.rank - 1) : undefined;
  const gapLine = playerEntry && above
    ? `${splitValue(Math.max(0, above.value - playerEntry.value), unit).num}${unit === 'TS' ? '' : ` ${splitValue(0, unit).suffix}`} behind No. ${above.rank}`
    : '';

  // Stable identities so the memoised EntryRow can bail out. The podium was
  // previously constructed inline as a JSX element on every render, remounting
  // the whole list header each time.
  const openProfile = useCallback(
    (entry: LeaderboardEntry) =>
      navigation.navigate('UserProfile', { userId: entry.userId, username: entry.name }),
    [navigation],
  );
  const listData = entries.length < 3 ? entries : entries.slice(3);
  const lastIndex = listData.length - 1;
  const renderItem = useCallback(
    ({ item, index }: { item: LeaderboardEntry; index: number }) => (
      <EntryRow
        entry={item}
        unit={unit}
        onPress={item.isPlayer ? undefined : openProfile}
        position={lastIndex === 0 ? 'only' : index === 0 ? 'first' : index === lastIndex ? 'last' : 'middle'}
      />
    ),
    [unit, openProfile, lastIndex],
  );
  const podium = useMemo(
    () => <Podium entries={entries} unit={unit} />,
    [entries, unit],
  );

  return (
    <SafeAreaView style={s.root}>
      <View style={s.header}>
        <Pressable onPress={() => navigation.goBack()} style={s.backBtn} hitSlop={8} accessibilityLabel="Back">
          <ArrowLeft size={20} color={C.t1} weight="regular" />
        </Pressable>
        <LeaderboardFilters
          part="pill"
          tab={tab} timeFrame={timeFrame} scope={scope}
          onTabChange={setTab} onTimeFrameChange={setTimeFrame} onScopeChange={setScope}
        />
      </View>
      <Text style={s.title}>Leaderboard</Text>
      <LeaderboardFilters
        part="segment"
        tab={tab} timeFrame={timeFrame} scope={scope}
        onTabChange={setTab} onTimeFrameChange={setTimeFrame} onScopeChange={setScope}
      />

      {loading ? (
        <SkeletonRows />
      ) : (
        <FlatList
          // Podium only renders (and only makes sense) at 3+ entries — below that,
          // slice(3) on a 1-2 entry array is empty, so the podium's own null-return
          // combined with an empty list rendered "No data yet" even when there WAS
          // data. Show every entry in the list until there are enough for a podium.
          data={listData}
          keyExtractor={keyExtractor}
          renderItem={renderItem}
          contentContainerStyle={s.list}
          showsVerticalScrollIndicator={false}
          // Page size is 100; without these the entire board mounts at once.
          initialNumToRender={12}
          windowSize={7}
          removeClippedSubviews
          ListHeaderComponent={podium}
          ListEmptyComponent={
            <View style={s.empty}>
              <Text style={s.emptyTitle}>Nobody's claimed the board yet.</Text>
              <Text style={s.emptyText}>Finish a run and be the first name up here.</Text>
            </View>
          }
        />
      )}

      {/* Sticky "You" bar — shown when the runner is outside the top 3 */}
      {!loading && playerOutsideTop3 && playerEntry && (
        <View style={s.playerFooter}>
          <Text style={s.playerRank}>{playerEntry.rank}</Text>
          <View style={s.playerAvatar}>
            <Text style={s.playerAvatarText}>{playerEntry.name.charAt(0).toUpperCase()}</Text>
          </View>
          <View style={{ flex: 1 }}>
            <Text style={s.playerName} numberOfLines={1}>You</Text>
            {!!gapLine && <Text style={s.playerLvl} numberOfLines={1}>{gapLine}</Text>}
          </View>
          <Text style={s.playerValue}>{playerVal?.num}{unit !== 'TS' ? <Text style={s.playerUnit}> {playerVal?.suffix}</Text> : null}</Text>
        </View>
      )}
    </SafeAreaView>
  );
}

function mkStyles(C: AppColors) {
  return StyleSheet.create({
    root: { flex: 1, backgroundColor: C.bg },
    header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 18, paddingTop: Platform.OS === 'android' ? 12 : 4, paddingBottom: 10 },
    backBtn: { width: 42, height: 42, borderRadius: 21, backgroundColor: C.card, alignItems: 'center', justifyContent: 'center' },
    title: { fontFamily: Fonts.bold, fontSize: 32, letterSpacing: -0.8, color: C.t1, paddingHorizontal: 18, marginBottom: 14 },
    list:          { paddingBottom: 120 },
    skeletonWrap:  { paddingTop: 8 },
    skeletonRow:   { height: 60, marginHorizontal: 12, marginBottom: 8, borderRadius: 18 },
    empty:         { alignItems: 'center' as const, paddingVertical: 48, paddingHorizontal: 16 },
    emptyTitle:    { fontFamily: Fonts.bold, fontSize: 20, lineHeight: 25, color: C.t1, marginBottom: 6, textAlign: 'center' },
    emptyText:     { fontFamily: Fonts.regular, fontSize: 13, color: C.t2, textAlign: 'center' },
    playerFooter:  { position: 'absolute', left: 14, right: 14, bottom: 28, flexDirection: 'row', alignItems: 'center', gap: 12, paddingHorizontal: 18, paddingVertical: 12, backgroundColor: C.red, borderRadius: 22, shadowColor: C.red, shadowOpacity: 0.3, shadowRadius: 16, shadowOffset: { width: 0, height: 6 }, elevation: 8 },
    playerRank:    { fontFamily: Fonts.numeric, fontSize: 26, color: C.alwaysLight, minWidth: 30 },
    playerAvatar:  { width: 38, height: 38, borderRadius: 19, backgroundColor: C.alwaysDark, alignItems: 'center', justifyContent: 'center' },
    playerAvatarText: { fontFamily: Fonts.semiBold, fontSize: 14, color: C.alwaysLight },
    playerName:    { fontFamily: Fonts.semiBold, fontSize: 15, color: C.alwaysLight },
    playerLvl:     { fontFamily: Fonts.regular, fontSize: 12, color: 'rgba(255,255,255,0.8)' },
    playerValue:   { fontFamily: Fonts.numeric, fontSize: 26, color: C.alwaysLight },
    playerUnit:    { fontFamily: Fonts.medium, fontSize: 11, color: 'rgba(255,255,255,0.8)' },
  });
}
