import React, { useMemo } from 'react';
import { View, Text, StyleSheet, Pressable, Image } from 'react-native';
import { GAME_CONFIG } from '@shared/services/config';
import { Avatar } from '@mobile/shared/components/Avatar';
import { useTheme, Fonts, Type, Spacing, type AppColors } from '@theme';

interface ProfileHeaderProps {
  displayName: string;
  username?: string;
  bio: string;
  avatarColor: string;
  avatarUri?: string | null;
  runnerRank: string;
  rankPct: number;
  /** e.g. "Strider → Chaser · 340 / 600 PACE" — computed by the caller from
   *  the existing rank ladder (GAME_CONFIG.RUNNER_RANK_THRESHOLDS), not here. */
  rankCaption: string;
  // kept for compat but not rendered in header
  totalKm: number;
  totalRuns: number;
  totalTerritories: number;
  totalAreaM2: number;
  /** Lifetime PACE, shown in the stat row. */
  paceTotalEarned?: number;
  thisWeekKm: number;
  weeklyGoalKm: number;
  followers: number;
  following: number;
  isOwnProfile?: boolean;
  onEditPress: () => void;
  onNotificationsPress: () => void;
  onSettingsPress: () => void;
  onFollowersPress?: () => void;
  onFollowingPress?: () => void;
  onTerritoryPress?: () => void;
  // unused below but kept for compat
  location?: string;
  instagram?: string;
  strava?: string;
}

const RANK_ORDER = ['pacer', 'strider', 'chaser', 'hunter', 'sovereign'] as const;
const RANK_THRESHOLDS = GAME_CONFIG.RUNNER_RANK_THRESHOLDS as Record<string, number>;

function fmtNum(n: number): string {
  return Math.round(n).toLocaleString();
}

export function ProfileHeader({
  displayName, username, bio, avatarColor, avatarUri,
  runnerRank, rankPct, rankCaption,
  totalKm, totalRuns, totalTerritories, paceTotalEarned,
  followers, location,
  isOwnProfile = true,
  onEditPress, onFollowersPress, onTerritoryPress,
}: ProfileHeaderProps) {
  const C = useTheme();
  const ss = useMemo(() => mkStyles(C), [C]);
  const displayRank = runnerRank.charAt(0).toUpperCase() + runnerRank.slice(1);
  const rankIdx = Math.max(0, RANK_ORDER.indexOf(runnerRank as typeof RANK_ORDER[number]));
  const nextRankKey = RANK_ORDER[rankIdx + 1];
  const nextRank = nextRankKey ? nextRankKey.charAt(0).toUpperCase() + nextRankKey.slice(1) : null;
  const toNext = nextRankKey ? Math.max(0, (RANK_THRESHOLDS[nextRankKey] ?? 0) - (paceTotalEarned ?? 0)) : 0;

  return (
    <View style={ss.header}>
      {/* Top actions */}
      {isOwnProfile && (
        <View style={ss.topBar}>
          <Pressable style={ss.pill} onPress={onEditPress} hitSlop={6}>
            <Text style={ss.pillText}>Edit profile</Text>
          </Pressable>
        </View>
      )}

      {/* Avatar + name */}
      <View style={ss.row}>
        <Pressable onPress={isOwnProfile ? onEditPress : undefined} style={ss.avatarRing}>
          {avatarUri ? (
            <Image source={{ uri: avatarUri }} style={ss.avatarImg} />
          ) : (
            <Avatar name={displayName} seed={username} color={avatarColor} size={82} />
          )}
        </Pressable>

        <View style={ss.infoBlock}>
          <Text style={ss.displayName} numberOfLines={1}>{displayName}</Text>
          <Pressable onPress={onFollowersPress} hitSlop={6} disabled={!onFollowersPress}>
            <Text style={ss.meta} numberOfLines={1}>
              {[username ? `@${username}` : null, location || null, `${followers} ${followers === 1 ? 'follower' : 'followers'}`]
                .filter(Boolean).join(' · ')}
            </Text>
          </Pressable>
        </View>
      </View>

      {!!bio && <Text style={ss.bio} numberOfLines={3} maxFontSizeMultiplier={1.2}>{bio}</Text>}

      {/* Rank card */}
      <View style={ss.card}>
        <View style={ss.rankTop}>
          <View style={ss.rankChip}>
            <Text style={ss.rankChipText}>{displayRank}</Text>
          </View>
          <Text style={ss.rankCaption} numberOfLines={1}>
            {nextRank ? <>{toNext.toLocaleString()} PACE to <Text style={ss.rankCaptionStrong}>{nextRank}</Text></> : rankCaption}
          </Text>
        </View>
        <View style={ss.barBg}>
          <View style={[ss.barFill, { width: `${Math.round(Math.max(0.02, Math.min(1, rankPct)) * 100)}%` }]} />
        </View>
        <View style={ss.ladder}>
          {RANK_ORDER.map((r, i) => (
            <Text key={r} style={[ss.ladderStep, i === rankIdx && ss.ladderStepOn]}>
              {r.charAt(0).toUpperCase() + r.slice(1)}
            </Text>
          ))}
        </View>
      </View>

      {/* Numbers */}
      <View style={[ss.card, ss.statRow]}>
        <View style={ss.stat}>
          <Text style={ss.statNum}>{fmtNum(totalKm)}</Text>
          <Text style={ss.statLabel}>km</Text>
        </View>
        <View style={[ss.stat, ss.statDivider]}>
          <Text style={ss.statNum}>{fmtNum(totalRuns)}</Text>
          <Text style={ss.statLabel}>Runs</Text>
        </View>
        <Pressable style={[ss.stat, ss.statDivider]} onPress={onTerritoryPress} disabled={!onTerritoryPress}>
          <Text style={[ss.statNum, { color: C.red }]}>{fmtNum(totalTerritories)}</Text>
          <Text style={ss.statLabel}>Zones</Text>
        </Pressable>
        <View style={[ss.stat, ss.statDivider]}>
          <Text style={ss.statNum}>{fmtNum(paceTotalEarned ?? 0)}</Text>
          <Text style={ss.statLabel}>PACE</Text>
        </View>
      </View>
    </View>
  );
}

function mkStyles(C: AppColors) {
  return StyleSheet.create({
    header:       { paddingHorizontal: Spacing.gutter, paddingTop: 12, paddingBottom: 8, gap: 12 },
    topBar:       { flexDirection: 'row', justifyContent: 'flex-end', alignItems: 'center', gap: 8 },
    pill:         {
      flexDirection: 'row', alignItems: 'center', gap: 6, height: 36, paddingHorizontal: 14,
      borderRadius: 999, borderWidth: 1, borderColor: C.border, backgroundColor: C.card,
    },
    pillText:     { ...Type.label, color: C.t1 },
    iconBtn:      {
      width: 36, height: 36, borderRadius: 18, alignItems: 'center', justifyContent: 'center',
      borderWidth: 1, borderColor: C.border, backgroundColor: C.card,
    },
    row:          { flexDirection: 'row', alignItems: 'center', gap: 14 },
    avatarRing:   { padding: 3, borderRadius: 48, borderWidth: 2, borderColor: C.red },
    avatarImg:    { width: 82, height: 82, borderRadius: 41 },
    infoBlock:    { flex: 1, gap: 4 },
    displayName:  { ...Type.displaySm, fontSize: 24, color: C.t1 },
    meta:         { ...Type.bodySm, color: C.t2 },
    socialLine:   { flexDirection: 'row', alignItems: 'center', gap: 14, marginTop: 2 },
    socialNum:    { fontFamily: Fonts.semiBold, fontSize: 13, color: C.t1 },
    socialLabel:  { fontFamily: Fonts.regular, fontSize: 13, color: C.t2 },
    bio:          { ...Type.bodySm, color: C.t2 },
    card:         {
      backgroundColor: C.card, borderRadius: Spacing.radius.lg, padding: 16,
      shadowColor: C.t1, shadowOpacity: 0.05, shadowRadius: 12, shadowOffset: { width: 0, height: 4 }, elevation: 1,
    },
    rankTop:      { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 10 },
    rankChip:     { backgroundColor: C.t1, paddingHorizontal: 9, paddingVertical: 4, borderRadius: 6 },
    rankCaptionStrong: { fontFamily: Fonts.bold, color: C.t1 },
    rankChipText: { fontFamily: Fonts.semiBold, fontSize: 12, color: C.bg },
    rankCaption:  { ...Type.bodySm, color: C.t2, flexShrink: 1, textAlign: 'right' },
    barBg:        { height: 8, backgroundColor: C.border, borderRadius: 4, overflow: 'hidden', marginTop: 12 },
    barFill:      { height: 8, backgroundColor: C.red, borderRadius: 4 },
    ladder:       { flexDirection: 'row', justifyContent: 'space-between', marginTop: 8 },
    ladderStep:   { fontFamily: Fonts.medium, fontSize: 12, color: C.t2 },
    ladderStepOn: { color: C.t1, fontFamily: Fonts.semiBold },
    statRow:      { flexDirection: 'row', paddingHorizontal: 4, paddingVertical: 14 },
    stat:         { flex: 1, alignItems: 'center' },
    statDivider:  { borderLeftWidth: 1, borderLeftColor: C.border },
    statNum:      { fontFamily: Fonts.numeric, fontSize: 28, lineHeight: 30, color: C.t1, fontVariant: ['tabular-nums'] },
    statLabel:    { fontFamily: Fonts.medium, fontSize: 12, color: C.t2, marginTop: 4 },
  });
}
