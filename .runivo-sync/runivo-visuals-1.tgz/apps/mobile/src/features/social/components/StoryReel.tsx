import React, { useMemo } from 'react';
import { View, Text, Pressable, ScrollView, StyleSheet } from 'react-native';
import { avatarColor } from '@shared/lib/avatarUtils';
import type { StoryGroup } from '@features/social/services/storyService';
import { useTheme, Fonts, type AppColors } from '@theme';
import { RunnerFace } from '@mobile/shared/components/RunnerFace';

interface Props {
  groups:   StoryGroup[];
  onPress:  (group: StoryGroup, index: number) => void;
}

export function StoryReel({ groups, onPress }: Props) {
  const C = useTheme();
  const s = useMemo(() => mkStyles(C), [C]);
  if (groups.length === 0) return null;

  return (
    <ScrollView
      horizontal
      showsHorizontalScrollIndicator={false}
      contentContainerStyle={s.list}
      style={s.root}
    >
      {groups.map((g, i) => {
        const bg      = avatarColor(g.userName);
        return (
          <Pressable key={g.userId} style={s.item} onPress={() => onPress(g, i)}>
            <View style={[s.ring, { borderColor: bg }]}>
              <View style={[s.avatar, { overflow: 'hidden' }]}>
                <RunnerFace seed={g.userName} size={48} />
              </View>
            </View>
            <Text style={s.name} numberOfLines={1}>{g.userName}</Text>
          </Pressable>
        );
      })}
    </ScrollView>
  );
}

function mkStyles(C: AppColors) {
  return StyleSheet.create({
    root:    { marginBottom: 4 },
    list:    { paddingHorizontal: 16, paddingVertical: 12, gap: 14 },
    item:    { alignItems: 'center', gap: 6, width: 62 },
    ring:    { width: 58, height: 58, borderRadius: 29, borderWidth: 2.5, padding: 2.5 },
    avatar:  { flex: 1, borderRadius: 24, alignItems: 'center', justifyContent: 'center' },
    initial: { fontFamily: Fonts.semiBold, fontSize: 18, color: C.white },
    name:    { fontFamily: Fonts.medium, fontSize: 11, color: C.t1, width: 62, textAlign: 'center' },
  });
}
