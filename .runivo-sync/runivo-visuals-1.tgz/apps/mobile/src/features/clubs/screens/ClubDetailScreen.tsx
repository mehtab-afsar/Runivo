import React, { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import {
  View, Text, StyleSheet, FlatList, Pressable, SafeAreaView,
  KeyboardAvoidingView, Platform, ActivityIndicator, Modal,
  TextInput, ScrollView,
} from 'react-native';
import { useNavigation, useRoute } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import type { RouteProp } from '@react-navigation/native';
import type { RootStackParamList } from '@navigation/AppNavigator';
import { ArrowLeft, Users, Pulse, ClipboardText, Check, X, type Icon } from 'phosphor-react-native';
import { getEmojiIcon } from '@mobile/shared/lib/emojiIcon';
import { useLobbyChat } from '@features/clubs/hooks/useLobbyChat';
import { ChatBubble } from '@features/clubs/components/ChatBubble';
import { ChatInput } from '@features/clubs/components/ChatInput';
import {
  fetchClubMembers,
  fetchClubActivity,
  fetchJoinRequests,
  approveJoinRequest,
  rejectJoinRequest,
  updateClubDescription,
  updateClubBadge,
  getOrCreateClubLobby,
} from '@features/clubs/services/clubService';
import type { ClubMember, ActivityItem, JoinRequest } from '@features/clubs/types';
import { supabase } from '@shared/services/supabase';
import { useTheme, Fonts, Type, Spacing, type AppColors } from '@theme';
import { RunnerFace } from '@mobile/shared/components/RunnerFace';

type Nav   = NativeStackNavigationProp<RootStackParamList>;
type Route = RouteProp<RootStackParamList, 'ClubDetail'>;

const BADGE_EMOJIS = [
  '🏃','⚡','🔥','💪','🏆','🌍','🦅','🐺','🦁','🌟',
  '🎯','🛡️','⚔️','🏔️','🌊','🦊','🐉','🚀','💎','🎖️',
];

const ACTION_LABELS: Record<string, string> = {
  captured: 'captured a territory',
  lost: 'lost a territory',
  defended: 'defended a territory',
  joined: 'joined the club',
  leveled_up: 'leveled up',
};

type DetailTab = 'chat' | 'members' | 'leaderboard' | 'activity' | 'admin';

function MemberRow({ member, rank, onPress }: { member: ClubMember; rank?: number; onPress: () => void }) {
  const C = useTheme();
  const mr = useMemo(() => mkMrStyles(C), [C]);
  return (
    <Pressable style={mr.row} onPress={onPress}>
      {rank !== undefined && (
        <Text style={[mr.rank, rank < 3 && mr.rankTop]}>{rank + 1}</Text>
      )}
      <View style={[mr.avatar, { overflow: 'hidden' }]}>
        <RunnerFace seed={member.username} size={38} />
      </View>
      <View style={{ flex: 1 }}>
        <View style={mr.nameRow}>
          <Text style={mr.name}>{member.username}</Text>
          {member.role === 'admin' && (
            <View style={mr.adminBadge}><Text style={mr.adminText}>Admin</Text></View>
          )}
        </View>
        <Text style={mr.meta}>Lv. {member.level}</Text>
      </View>
      <Text style={mr.kmVal}>{member.total_km.toFixed(0)}<Text style={mr.kmUnit}> km</Text></Text>
    </Pressable>
  );
}

function mkMrStyles(C: AppColors) {
  return StyleSheet.create({
    row:       { flexDirection: 'row', alignItems: 'center', gap: 10, backgroundColor: C.card, borderRadius: 16, shadowColor: C.t1, shadowOpacity: 0.05, shadowRadius: 12, shadowOffset: { width: 0, height: 4 }, elevation: 1, padding: 12, marginBottom: 6 },
    rank:      { width: 30, textAlign: 'center', fontFamily: Fonts.numeric, fontSize: 22, lineHeight: 24, color: C.t2, fontVariant: ['tabular-nums'] },
    rankTop:   { color: C.red },
    avatar:    { width: 38, height: 38, borderRadius: 19, alignItems: 'center', justifyContent: 'center', flexShrink: 0 },
    avatarText:{ fontFamily: Fonts.bold, fontSize: 12, color: C.white },
    nameRow:   { flexDirection: 'row', alignItems: 'center', gap: 6 },
    name:      { fontFamily: Fonts.semiBold, fontSize: 14, color: C.t1 },
    adminBadge:{ backgroundColor: C.redLo, borderRadius: 999, paddingHorizontal: 7, paddingVertical: 2 },
    adminText: { fontFamily: Fonts.semiBold, fontSize: 11, color: C.red },
    meta:      { fontFamily: Fonts.regular, fontSize: 11, color: C.t3, marginTop: 2 },
    kmVal:     { fontFamily: Fonts.numeric, fontSize: 22, lineHeight: 24, color: C.t1, fontVariant: ['tabular-nums'] },
    kmUnit:    { fontFamily: Fonts.medium, fontSize: 11, color: C.t3 },
  });
}

function ActivityRow({ item }: { item: ActivityItem }) {
  const C = useTheme();
  const ar = useMemo(() => mkArStyles(C), [C]);
  const label = ACTION_LABELS[item.action] ?? item.action;
  const timeAgo = (() => {
    const diff = Date.now() - new Date(item.time).getTime();
    const mins = Math.floor(diff / 60000);
    if (mins < 60) return `${mins}m ago`;
    const hrs = Math.floor(mins / 60);
    if (hrs < 24) return `${hrs}h ago`;
    return `${Math.floor(hrs / 24)}d ago`;
  })();

  return (
    <View style={ar.row}>
      <View style={[ar.avatar, { overflow: 'hidden' }]}>
        <RunnerFace seed={item.username} size={32} />
      </View>
      <View style={{ flex: 1 }}>
        <Text style={ar.text}>
          <Text style={ar.username}>{item.username}</Text>
          {' '}{label}{item.detail ? ` · ${item.detail}` : ''}
        </Text>
        <Text style={ar.time}>{timeAgo}</Text>
      </View>
    </View>
  );
}

function mkArStyles(C: AppColors) {
  return StyleSheet.create({
    row:       { flexDirection: 'row', alignItems: 'flex-start', gap: 10, paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: C.border },
    avatar:    { width: 32, height: 32, borderRadius: 16, alignItems: 'center', justifyContent: 'center', flexShrink: 0, marginTop: 1 },
    avatarText:{ fontFamily: Fonts.bold, fontSize: 11, color: C.white },
    text:      { fontFamily: Fonts.regular, fontSize: 13, color: C.t2, lineHeight: 19 },
    username:  { fontFamily: Fonts.semiBold, color: C.t1 },
    time:      { fontFamily: Fonts.regular, fontSize: 11, color: C.t3, marginTop: 2 },
  });
}

export default function ClubDetailScreen() {
  const C = useTheme();
  const s = useMemo(() => mkStyles(C), [C]);
  const navigation = useNavigation<Nav>();
  const { clubId, clubName, badgeEmoji, memberCount, totalKm, description: initialDesc } = useRoute<Route>().params as any;
  const { icon: BadgeIcon, color: badgeColor } = getEmojiIcon(badgeEmoji);
  const [tab, setTab] = useState<DetailTab>('chat');
  const [currentUserId, setCurrentUserId] = useState<string | null>(null);
  const [currentUserRole, setCurrentUserRole] = useState<'admin' | 'member' | null>(null);
  const [clubLobbyId, setClubLobbyId] = useState<string | null>(null);
  const listRef = useRef<FlatList>(null);

  // Members tab
  const [members, setMembers] = useState<ClubMember[]>([]);
  const [membersLoading, setMembersLoading] = useState(false);

  // Leaderboard tab (same data, sorted differently)
  const [leaderboard, setLeaderboard] = useState<ClubMember[]>([]);
  const [leaderboardLoading, setLeaderboardLoading] = useState(false);

  // Activity tab
  const [activity, setActivity] = useState<ActivityItem[]>([]);
  const [activityLoading, setActivityLoading] = useState(false);

  // Admin tab
  const [joinRequests, setJoinRequests] = useState<JoinRequest[]>([]);
  const [requestsLoading, setRequestsLoading] = useState(false);
  const [description, setDescription] = useState<string>(initialDesc ?? '');
  const [savingDesc, setSavingDesc] = useState(false);
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);

  // Resolves to '' until the club's lobby id loads — useLobbyChat's fetch/subscribe
  // are harmless no-ops against an empty id (no row can match) until then.
  const { messages, loading: chatLoading, inputText, setInputText, sending, sendMessage } = useLobbyChat(clubLobbyId ?? '');

  useEffect(() => {
    supabase.auth.getUser().then(async ({ data: { user } }) => {
      if (!user) return;
      setCurrentUserId(user.id);
      // Check role in this club
      const { data } = await supabase
        .from('club_members')
        .select('role')
        .eq('club_id', clubId)
        .eq('user_id', user.id)
        .maybeSingle();
      if (data) setCurrentUserRole(data.role as 'admin' | 'member');

      const lobbyId = await getOrCreateClubLobby(clubId, clubName, user.id);
      setClubLobbyId(lobbyId);
    });
  }, [clubId, clubName]);

  useEffect(() => {
    if (messages.length > 0) {
      setTimeout(() => listRef.current?.scrollToEnd({ animated: true }), 100);
    }
  }, [messages.length]);

  const loadMembers = useCallback(async () => {
    setMembersLoading(true);
    try {
      const data = await fetchClubMembers(clubId);
      setMembers(data);
    } catch { /* offline */ }
    setMembersLoading(false);
  }, [clubId]);

  const loadLeaderboard = useCallback(async () => {
    setLeaderboardLoading(true);
    try {
      const data = await fetchClubMembers(clubId);
      setLeaderboard(data); // already sorted by total_km desc in service
    } catch { /* offline */ }
    setLeaderboardLoading(false);
  }, [clubId]);

  const loadActivity = useCallback(async () => {
    setActivityLoading(true);
    try {
      const data = await fetchClubActivity(clubId);
      setActivity(data);
    } catch { /* offline */ }
    setActivityLoading(false);
  }, [clubId]);

  const loadRequests = useCallback(async () => {
    setRequestsLoading(true);
    try {
      const data = await fetchJoinRequests(clubId);
      setJoinRequests(data);
    } catch { /* offline */ }
    setRequestsLoading(false);
  }, [clubId]);

  useEffect(() => {
    if (tab === 'members') loadMembers();
    else if (tab === 'leaderboard') loadLeaderboard();
    else if (tab === 'activity') loadActivity();
    else if (tab === 'admin') loadRequests();
  }, [tab, loadMembers, loadLeaderboard, loadActivity, loadRequests]);

  const handleSaveDesc = async () => {
    setSavingDesc(true);
    await updateClubDescription(clubId, description);
    setSavingDesc(false);
  };

  const handleBadgeSelect = async (emoji: string) => {
    setShowEmojiPicker(false);
    await updateClubBadge(clubId, emoji);
  };

  const handleApprove = async (req: JoinRequest) => {
    const { ok } = await approveJoinRequest(req.id);
    if (ok) {
      setJoinRequests(prev => prev.filter(r => r.id !== req.id));
      loadMembers();
    }
  };

  const handleReject = async (req: JoinRequest) => {
    const { ok } = await rejectJoinRequest(req.id);
    if (ok) setJoinRequests(prev => prev.filter(r => r.id !== req.id));
  };

  const tabs: { key: DetailTab; label: string }[] = [
    { key: 'chat', label: 'Chat' },
    { key: 'members', label: 'Members' },
    { key: 'leaderboard', label: 'Top' },
    { key: 'activity', label: 'Activity' },
    ...(currentUserRole === 'admin' ? [{ key: 'admin' as DetailTab, label: 'Admin' }] : []),
  ];

  return (
    <SafeAreaView style={s.root}>
      {/* Header */}
      <View style={s.header}>
        <Pressable onPress={() => navigation.goBack()} style={s.backBtn} accessibilityLabel="Back">
          <ArrowLeft size={18} color={C.t1} weight="bold" />
        </Pressable>
      </View>

      {/* Club hero */}
      <View style={s.hero}>
        <View style={s.heroTop}>
          <View style={s.emoji}><BadgeIcon size={26} color={badgeColor} weight="light" /></View>
          <View style={{ flex: 1 }}>
            <Text style={s.title} numberOfLines={1}>{clubName}</Text>
            {currentUserRole === 'admin' && <Text style={s.heroRole}>You're an admin</Text>}
          </View>
        </View>
        <View style={s.heroStats}>
          <View style={s.heroStat}>
            <View style={s.heroStatLabelRow}>
              <Users size={12} color={C.alwaysLight} weight="regular" />
              <Text style={s.subtitle}>Members</Text>
            </View>
            <Text style={s.heroNum}>{memberCount}</Text>
          </View>
          <View style={s.heroStat}>
            <View style={s.heroStatLabelRow}>
              <Pulse size={12} color={C.alwaysLight} weight="regular" />
              <Text style={s.subtitle}>Total km</Text>
            </View>
            <Text style={s.heroNum}>{Math.round(totalKm).toLocaleString()}</Text>
          </View>
        </View>
      </View>

      {/* Tab bar */}
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        style={s.tabScroll}
        contentContainerStyle={s.tabBar}
      >
        {tabs.map(t => (
          <Pressable key={t.key} style={[s.tabBtn, tab === t.key && s.tabBtnActive]} onPress={() => setTab(t.key)}>
            <Text style={[s.tabLabel, tab === t.key && s.tabLabelActive]}>{t.label}</Text>
          </Pressable>
        ))}
      </ScrollView>

      {/* Chat tab */}
      {tab === 'chat' && (
        <KeyboardAvoidingView
          style={{ flex: 1 }}
          behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
          keyboardVerticalOffset={Platform.OS === 'ios' ? 0 : 20}
        >
          {chatLoading ? (
            <View style={s.loader}><ActivityIndicator color={C.red} /></View>
          ) : messages.length === 0 ? (
            <View style={s.empty}>
              <BadgeIcon size={40} color={badgeColor} weight="light" />
              <Text style={s.emptyTitle}>No messages yet</Text>
              <Text style={s.emptyText}>Start the conversation with your club!</Text>
            </View>
          ) : (
            <FlatList
              ref={listRef}
              data={messages}
              keyExtractor={msg => msg.id}
              renderItem={({ item }) => (
                <ChatBubble message={item} isOwn={item.userId === currentUserId} />
              )}
              contentContainerStyle={{ paddingVertical: 12 }}
              showsVerticalScrollIndicator={false}
            />
          )}
          <ChatInput value={inputText} onChange={setInputText} onSend={sendMessage} sending={sending} />
        </KeyboardAvoidingView>
      )}

      {/* Members tab */}
      {tab === 'members' && (
        membersLoading ? (
          <View style={s.loader}><ActivityIndicator color={C.red} /></View>
        ) : (
          <FlatList
            data={members}
            keyExtractor={mb => mb.id}
            renderItem={({ item }) => (
              <MemberRow
                member={item}
                onPress={() => navigation.navigate('UserProfile', { userId: item.id, username: item.username })}
              />
            )}
            contentContainerStyle={s.listContent}
            showsVerticalScrollIndicator={false}
            ListEmptyComponent={
              <View style={s.empty}>
                <Text style={s.emptyTitle}>No members found</Text>
              </View>
            }
          />
        )
      )}

      {/* Leaderboard tab */}
      {tab === 'leaderboard' && (
        leaderboardLoading ? (
          <View style={s.loader}><ActivityIndicator color={C.red} /></View>
        ) : (
          <FlatList
            data={leaderboard}
            keyExtractor={mb => mb.id}
            renderItem={({ item, index }) => (
              <MemberRow
                member={item}
                rank={index}
                onPress={() => navigation.navigate('UserProfile', { userId: item.id, username: item.username })}
              />
            )}
            contentContainerStyle={s.listContent}
            showsVerticalScrollIndicator={false}
            ListHeaderComponent={
              <Text style={s.sectionLabel}>Ranked by total km</Text>
            }
            ListEmptyComponent={
              <View style={s.empty}>
                <Text style={s.emptyTitle}>No members yet</Text>
              </View>
            }
          />
        )
      )}

      {/* Activity tab */}
      {tab === 'activity' && (
        activityLoading ? (
          <View style={s.loader}><ActivityIndicator color={C.red} /></View>
        ) : (
          <FlatList
            data={activity}
            keyExtractor={a => a.id}
            renderItem={({ item }) => <ActivityRow item={item} />}
            contentContainerStyle={s.listContent}
            showsVerticalScrollIndicator={false}
            ListHeaderComponent={
              <Text style={s.sectionLabel}>Recent activity</Text>
            }
            ListEmptyComponent={
              <View style={s.empty}>
                <ClipboardText size={36} color={C.t3} weight="light" />
                <Text style={s.emptyTitle}>No activity yet</Text>
                <Text style={s.emptyText}>Club runs and events will appear here.</Text>
              </View>
            }
          />
        )
      )}

      {/* Admin tab */}
      {tab === 'admin' && (
        <ScrollView contentContainerStyle={s.adminContent} showsVerticalScrollIndicator={false}>
          {/* Description edit */}
          <Text style={s.sectionLabel}>Club description</Text>
          <View style={s.adminCard}>
            <TextInput
              style={s.descInput}
              value={description}
              onChangeText={setDescription}
              placeholder="Add a description…"
              placeholderTextColor={C.t3}
              multiline
              maxLength={280}
            />
            <Pressable
              style={[s.saveBtn, savingDesc && s.saveBtnDisabled]}
              onPress={handleSaveDesc}
              disabled={savingDesc}
            >
              {savingDesc ? (
                <ActivityIndicator size="small" color={C.alwaysLight} />
              ) : (
                <Text style={s.saveBtnText}>Save</Text>
              )}
            </Pressable>
          </View>

          {/* Badge emoji edit */}
          <Text style={[s.sectionLabel, { marginTop: 20 }]}>Club badge</Text>
          <View style={s.adminCard}>
            <View style={s.badgeRow}>
              <View style={s.bigEmoji}><BadgeIcon size={40} color={badgeColor} weight="light" /></View>
              <Pressable style={s.changeBtn} onPress={() => setShowEmojiPicker(true)}>
                <Text style={s.changeBtnText}>Change badge</Text>
              </Pressable>
            </View>
          </View>

          {/* Join requests */}
          <Text style={[s.sectionLabel, { marginTop: 20 }]}>Join requests</Text>
          {requestsLoading ? (
            <ActivityIndicator color={C.red} style={{ marginTop: 16 }} />
          ) : joinRequests.length === 0 ? (
            <View style={s.adminCard}>
              <Text style={s.noRequestsText}>No pending requests</Text>
            </View>
          ) : (
            joinRequests.map(req => (
              <View key={req.id} style={s.requestRow}>
                <View style={[s.reqAvatar, { overflow: 'hidden' }]}>
                  <RunnerFace seed={req.username} size={34} />
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={s.reqName}>{req.username}</Text>
                  <Text style={s.reqTime}>{new Date(req.requestedAt).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}</Text>
                </View>
                <Pressable style={s.approveBtn} onPress={() => handleApprove(req)}>
                  <Check size={14} color={C.green} weight="regular" />
                </Pressable>
                <Pressable style={s.rejectBtn} onPress={() => handleReject(req)}>
                  <X size={14} color={C.red} weight="regular" />
                </Pressable>
              </View>
            ))
          )}
        </ScrollView>
      )}

      {/* Badge emoji picker modal */}
      <Modal visible={showEmojiPicker} transparent animationType="fade" onRequestClose={() => setShowEmojiPicker(false)}>
        <Pressable style={s.overlay} onPress={() => setShowEmojiPicker(false)}>
          <View style={s.badgePickerSheet}>
            <Text style={s.pickerLabel}>Choose a badge</Text>
            <View style={s.badgeGrid}>
              {BADGE_EMOJIS.map(emoji => {
                const { icon: PickIcon, color: pickColor } = getEmojiIcon(emoji);
                return (
                  <Pressable key={emoji} style={s.badgePickerBtn} onPress={() => handleBadgeSelect(emoji)}>
                    <PickIcon size={22} color={pickColor} weight="light" />
                  </Pressable>
                );
              })}
            </View>
          </View>
        </Pressable>
      </Modal>
    </SafeAreaView>
  );
}

function mkStyles(C: AppColors) {
  return StyleSheet.create({
    root:        { flex: 1, backgroundColor: C.bg },
    header:      { flexDirection: 'row', alignItems: 'center', paddingHorizontal: Spacing.gutter, paddingTop: Platform.OS === 'android' ? 12 : 4, paddingBottom: 10 },
    backBtn:     { width: 36, height: 36, borderRadius: 18, alignItems: 'center', justifyContent: 'center', backgroundColor: C.card, borderWidth: 1, borderColor: C.border },
    backText:    { fontFamily: Fonts.regular, fontSize: 18, color: C.t2 },
    hero:        { marginHorizontal: Spacing.gutter, marginBottom: 12, backgroundColor: C.alwaysDark, borderRadius: Spacing.radius.xl, padding: 18 },
    heroTop:     { flexDirection: 'row', alignItems: 'center', gap: 12 },
    emoji:       { width: 52, height: 52, borderRadius: 14, backgroundColor: 'rgba(255,255,255,0.10)', alignItems: 'center', justifyContent: 'center' },
    title:       { fontFamily: Fonts.bold, fontSize: 22, color: C.alwaysLight, letterSpacing: -0.4 },
    heroRole:    { fontFamily: Fonts.medium, fontSize: 12, color: C.alwaysLight, opacity: 0.6, marginTop: 2 },
    heroStats:   { flexDirection: 'row', gap: 12, marginTop: 18 },
    heroStat:    { flex: 1 },
    heroStatLabelRow: { flexDirection: 'row', alignItems: 'center', gap: 5, opacity: 0.6 },
    subtitle:    { fontFamily: Fonts.medium, fontSize: 12, color: C.alwaysLight },
    heroNum:     { fontFamily: Fonts.numeric, fontSize: 36, lineHeight: 38, color: C.alwaysLight, marginTop: 2, fontVariant: ['tabular-nums'] },
    // Tab bar
    tabScroll:   { flexGrow: 0, backgroundColor: C.bg },
    tabBar:      { flexDirection: 'row', paddingHorizontal: Spacing.gutter, gap: 8, paddingBottom: 6 },
    tabBtn:      { height: 36, paddingHorizontal: 16, justifyContent: 'center', borderRadius: 999, borderWidth: 1, borderColor: C.border, backgroundColor: C.card },
    tabBtnActive:{ backgroundColor: C.t1, borderColor: C.t1 },
    tabLabel:    { fontFamily: Fonts.medium, fontSize: 13, color: C.t2 },
    tabLabelActive: { fontFamily: Fonts.semiBold, color: C.bg },
    // Common
    loader:      { flex: 1, alignItems: 'center', justifyContent: 'center' },
    empty:       { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 32, gap: 10 },
    emptyTitle:  { fontFamily: Fonts.semiBold, fontSize: 18, color: C.t1 },
    emptyText:   { ...Type.bodySm, color: C.t2, textAlign: 'center' },
    listContent: { paddingHorizontal: Spacing.gutter, paddingTop: 12, paddingBottom: 100 },
    sectionLabel:{ fontFamily: Fonts.semiBold, fontSize: 15, color: C.t1, marginBottom: 10 },
    // Admin
    adminContent:{ paddingHorizontal: Spacing.gutter, paddingTop: 16, paddingBottom: 100, gap: 0 },
    adminCard:   { backgroundColor: C.card, borderRadius: 16, shadowColor: C.t1, shadowOpacity: 0.05, shadowRadius: 12, shadowOffset: { width: 0, height: 4 }, elevation: 1, padding: 14, marginBottom: 4 },
    descInput:   { fontFamily: Fonts.regular, fontSize: 13, color: C.t1, minHeight: 72, textAlignVertical: 'top', lineHeight: 20 },
    saveBtn:     { marginTop: 10, backgroundColor: C.red, borderRadius: 999, height: 44, justifyContent: 'center', alignItems: 'center' },
    saveBtnDisabled: { opacity: 0.5 },
    saveBtnText: { ...Type.button, fontSize: 14, color: C.alwaysLight },
    badgeRow:    { flexDirection: 'row', alignItems: 'center', gap: 16 },
    bigEmoji:    { alignItems: 'center', justifyContent: 'center' },
    changeBtn:   { backgroundColor: C.card, borderRadius: 999, paddingHorizontal: 16, height: 38, justifyContent: 'center', borderWidth: 1, borderColor: C.border },
    changeBtnText: { fontFamily: Fonts.semiBold, fontSize: 13, color: C.t1 },
    noRequestsText: { fontFamily: Fonts.regular, fontSize: 12, color: C.t3, textAlign: 'center' },
    requestRow:  { flexDirection: 'row', alignItems: 'center', gap: 10, backgroundColor: C.card, borderRadius: 16, shadowColor: C.t1, shadowOpacity: 0.05, shadowRadius: 12, shadowOffset: { width: 0, height: 4 }, elevation: 1, padding: 12, marginBottom: 6 },
    reqAvatar:   { width: 34, height: 34, borderRadius: 17, alignItems: 'center', justifyContent: 'center' },
    reqAvatarText: { fontFamily: Fonts.bold, fontSize: 12, color: C.white },
    reqName:     { fontFamily: Fonts.medium, fontSize: 13, color: C.t1 },
    reqTime:     { fontFamily: Fonts.regular, fontSize: 11, color: C.t3, marginTop: 2 },
    approveBtn:  { width: 34, height: 34, borderRadius: 17, backgroundColor: C.greenBg, borderWidth: 0.5, borderColor: C.green, alignItems: 'center', justifyContent: 'center' },
    approveBtnText: { fontFamily: Fonts.bold, fontSize: 13, color: C.green },
    rejectBtn:   { width: 34, height: 34, borderRadius: 17, backgroundColor: C.redLo, borderWidth: 0.5, borderColor: C.red, alignItems: 'center', justifyContent: 'center' },
    rejectBtnText: { fontFamily: Fonts.bold, fontSize: 13, color: C.red },
    overlay:     { flex: 1, backgroundColor: 'rgba(0,0,0,0.35)', alignItems: 'center', justifyContent: 'center' },
    pickerLabel: { fontFamily: Fonts.semiBold, fontSize: 15, color: C.t1 },
    // Badge picker
    badgePickerSheet: { backgroundColor: C.card, borderRadius: 20, padding: 20, alignItems: 'center', gap: 16, width: 320, shadowColor: '#000', shadowOffset: { width: 0, height: 8 }, shadowOpacity: 0.15, shadowRadius: 24, elevation: 10 },
    badgeGrid:   { flexDirection: 'row', flexWrap: 'wrap', gap: 8, justifyContent: 'center' },
    badgePickerBtn: { width: 50, height: 50, borderRadius: 25, backgroundColor: C.stone, alignItems: 'center', justifyContent: 'center' },
  });
}
