import { useState, useEffect, useCallback, useMemo } from 'react';
import * as ImagePicker from 'expo-image-picker';
import type { StoredRun } from '@shared/services/store';
import { getSettings, saveSettings } from '@shared/services/store';
import { supabase } from '@shared/services/supabase';
import {
  fetchProfileData, updateProfile, uploadAvatar,
  fetchAwards, fetchProfileStats, setPinnedRun, fetchFollowCounts,
} from '../services/profileService';
import type { ProfileTab } from '../types';
import type { ProfileStats } from '@shared/types/game';

const SWATCHES = ['#0A0A0A', '#D93518', '#3B82F6', '#1A6B40', '#F59E0B', '#8B5CF6'];

export interface PersonalRecord {
  label: string;
  value: string;
}

export function useProfile() {
  const [runs, setRuns] = useState<StoredRun[]>([]);
  const [weeklyGoalKm, setWeeklyGoalKm] = useState(20);
  const [personalRecords, setPersonalRecords] = useState<PersonalRecord[]>([]);
  const [tab, setTab] = useState<ProfileTab>('overview');

  const [followers, setFollowers] = useState(0);
  const [following, setFollowing] = useState(0);

  // New: awards, stats, pinned run
  const [earnedAwards, setEarnedAwards] = useState<{ awardId: string; unlockedAt: string }[]>([]);
  const [statsPeriod, setStatsPeriod] = useState<'week' | 'month' | 'year' | 'all'>('all');
  const [statsData, setStatsData] = useState<ProfileStats>({ totalKm: 0, totalRuns: 0, avgPaceSec: 0, totalCalories: 0, totalZones: 0 });
  const [pinnedRunId, setPinnedRunId] = useState<string | null>(null);
  const [avatarColor, setAvatarColor] = useState(SWATCHES[0]);
  const [avatarUri, setAvatarUri] = useState<string | null>(null);
  const [displayName, setDisplayName] = useState('');
  const [bio, setBio] = useState('');
  const [location, setLocation] = useState('');
  const [instagram, setInstagram] = useState('');
  const [strava, setStrava] = useState('');

  const [isEditing, setIsEditing] = useState(false);
  const [editName, setEditName] = useState('');
  const [editColor, setEditColor] = useState(SWATCHES[0]);
  const [editBio, setEditBio] = useState('');
  const [editLocation, setEditLocation] = useState('');
  const [editInstagram, setEditInstagram] = useState('');
  const [editStrava, setEditStrava] = useState('');
  const [editAvatarUri, setEditAvatarUri] = useState<string | null>(null);

  const load = useCallback(async () => {
    const data = await fetchProfileData();
    setRuns(data.runs);
    setWeeklyGoalKm(data.weeklyGoalKm);
    setPersonalRecords(data.personalRecords);
    setFollowers(data.followers);
    setFollowing(data.following);
    if (data.avatarColor) setAvatarColor(data.avatarColor);
    if (data.displayName) setDisplayName(data.displayName);
    if (data.bio) setBio(data.bio);
    if (data.location) setLocation(data.location);
    if (data.instagram) setInstagram(data.instagram);
    if (data.strava) setStrava(data.strava);
    if (data.avatarUrl) setAvatarUri(data.avatarUrl);

    // Sync Supabase profile preferences back to local settings store
    // so other screens (dashboard weekly goal, distance unit, etc.) pick them up
    const toWrite: Partial<Parameters<typeof saveSettings>[0]> = {};
    if (data.weeklyGoalKm != null) toWrite.weeklyGoalKm = data.weeklyGoalKm;
    if (data.distanceUnit === 'km' || data.distanceUnit === 'mi') toWrite.distanceUnit = data.distanceUnit;
    if (data.notificationsEnabled != null) toWrite.notificationsEnabled = data.notificationsEnabled;
    if (data.profileVisibility === 'public' || data.profileVisibility === 'followers' || data.profileVisibility === 'private') {
      toWrite.privacy = data.profileVisibility;
    }
    if (Object.keys(toWrite).length > 0) {
      const current = await getSettings();
      await saveSettings({ ...current, ...toWrite });
    }

    // Load awards and stats
    const { data: { session } } = await supabase.auth.getSession();
    if (session) {
      const [awards, stats] = await Promise.all([
        fetchAwards(session.user.id),
        fetchProfileStats(session.user.id, 'all'),
      ]);
      setEarnedAwards(awards);
      setStatsData(stats);
    }
  }, []);

  const loadStats = useCallback(async (period: 'week' | 'month' | 'year' | 'all') => {
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) return;
    const stats = await fetchProfileStats(session.user.id, period);
    setStatsData(stats);
  }, []);

  // Cheap, focus-triggered refresh — full `load()` reloads runs/records/awards
  // and would flash the loading state every time this tab regains focus.
  // Counts alone are the one thing that reliably goes stale after following
  // someone from FollowersScreen/FollowingScreen and tabbing back here.
  const refreshCounts = useCallback(async () => {
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) return;
    const { followers: f, following: g } = await fetchFollowCounts(session.user.id);
    setFollowers(f);
    setFollowing(g);
  }, []);

  useEffect(() => { load(); }, [load]);

  const thisWeekKm = useMemo(() => {
    const now = new Date();
    const todayIdx = now.getDay() === 0 ? 6 : now.getDay() - 1;
    const weekStart = new Date(now);
    weekStart.setDate(now.getDate() - todayIdx);
    weekStart.setHours(0, 0, 0, 0);
    return runs
      .filter(r => r.startTime >= weekStart.getTime())
      .filter(r => !r.excluded).reduce((s, r) => s + r.distanceMeters / 1000, 0);
  }, [runs]);

  const pickAvatar = useCallback(async () => {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== 'granted') return;
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true, aspect: [1, 1], quality: 0.8,
    });
    if (!result.canceled && result.assets[0]) {
      setEditAvatarUri(result.assets[0].uri);
    }
  }, []);

  const startEdit = useCallback(() => {
    setEditName(displayName);
    setEditColor(avatarColor);
    setEditBio(bio);
    setEditLocation(location);
    setEditInstagram(instagram);
    setEditStrava(strava);
    setEditAvatarUri(avatarUri);
    setIsEditing(true);
  }, [displayName, avatarColor, bio, location, instagram, strava, avatarUri]);

  const cancelEdit = useCallback(() => setIsEditing(false), []);

  const saveEdit = useCallback(async () => {
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) return;
    let newAvatarUrl: string | undefined;
    if (editAvatarUri && editAvatarUri !== avatarUri) {
      const url = await uploadAvatar(session.user.id, editAvatarUri);
      if (url) newAvatarUrl = url;
    }
    await updateProfile(session.user.id, {
      display_name: editName,
      bio: editBio,
      avatar_color: editColor,
      location: editLocation,
      instagram: editInstagram,
      strava: editStrava,
      ...(newAvatarUrl ? { avatar_url: newAvatarUrl } : {}),
    });
    setDisplayName(editName);
    setBio(editBio);
    setAvatarColor(editColor);
    setLocation(editLocation);
    setInstagram(editInstagram);
    setStrava(editStrava);
    if (newAvatarUrl) setAvatarUri(newAvatarUrl);
    setIsEditing(false);
  }, [editName, editBio, editColor, editLocation, editInstagram, editStrava, editAvatarUri, avatarUri]);

  const pinRun = useCallback(async (runId: string | null) => {
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) return;
    await setPinnedRun(session.user.id, runId);
    setPinnedRunId(runId);
  }, []);

  return {
    runs, weeklyGoalKm, personalRecords, thisWeekKm,
    followers, following,
    tab, setTab,
    avatarColor, avatarUri, displayName, bio, location, instagram, strava,
    isEditing,
    editName, setEditName,
    editColor, setEditColor,
    editBio, setEditBio,
    editLocation, setEditLocation,
    editInstagram, setEditInstagram,
    editStrava, setEditStrava,
    editAvatarUri, pickAvatar,
    startEdit, saveEdit, cancelEdit,
    earnedAwards,
    statsData, statsPeriod, setStatsPeriod: (p: 'week' | 'month' | 'year' | 'all') => {
      setStatsPeriod(p);
      loadStats(p);
    },
    pinnedRunId, pinRun,
    refreshCounts,
  };
}
