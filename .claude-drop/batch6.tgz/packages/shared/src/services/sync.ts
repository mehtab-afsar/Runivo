/**
 * Sync service — bridges the local IndexedDB cache with Supabase.
 *
 * Strategy:
 *  - Local IndexedDB is the source of truth while offline.
 *  - On network restore, unsynced runs are pushed to Supabase.
 *  - Territories are pulled from Supabase on app launch and after each run.
 *  - Profile stats are upserted to Supabase whenever they change locally.
 *
 * Reads flow:  Supabase → IndexedDB (local cache)
 * Writes flow: IndexedDB (optimistic) → Supabase (confirmed)
 */

import { supabase } from './supabase';
import { isPlus } from '../engine/entitlements';

// ----------------------------------------------------------------
// AI COACH ENABLEMENT — the app's own FEATURES.AI_COACH flag, mirrored here.
// This package can't import apps/mobile's config directly (wrong dependency
// direction — shared is also usable from apps/web), so the app calls
// setAiCoachEnabled() once at boot, same pattern as setSoundEnabled/
// setHapticEnabled in the theme layer.
//
// Without this, the auto post-run debrief below called the ai-coach edge
// function — sending heart rate, HRV, cadence and calorie data to Anthropic —
// on every completed run regardless of the flag, for a feature no user could
// even see. Defaults to false: no debrief call happens unless the app
// explicitly turns this on.
// ----------------------------------------------------------------
let _aiCoachEnabled = false;
export function setAiCoachEnabled(enabled: boolean): void { _aiCoachEnabled = enabled; }

// ----------------------------------------------------------------
// SYNC STATUS — subscribe to know when a sync is in-flight or failed
// ----------------------------------------------------------------

export type SyncStatus = 'idle' | 'syncing' | 'error' | 'offline';
let _syncStatus: SyncStatus = 'idle';
const _statusListeners: ((s: SyncStatus) => void)[] = [];

export function getSyncStatus(): SyncStatus { return _syncStatus; }

export function onSyncStatusChange(fn: (s: SyncStatus) => void): () => void {
  _statusListeners.push(fn);
  return () => { _statusListeners.splice(_statusListeners.indexOf(fn), 1); };
}

function setSyncStatus(s: SyncStatus): void {
  _syncStatus = s;
  _statusListeners.forEach(fn => fn(s));
}

function computeLargestTier(polygons: { tier: string }[]): string {
  const order = ['patch', 'block', 'district', 'quarter', 'domain'];
  return polygons.reduce((best, p) =>
    order.indexOf(p.tier) > order.indexOf(best) ? p.tier : best, 'patch');
}

async function withRetry<T>(fn: () => Promise<T>, attempts = 3): Promise<T> {
  for (let i = 0; i < attempts; i++) {
    try {
      return await fn();
    } catch (err) {
      if (i === attempts - 1) throw err;
      await new Promise<void>(r => setTimeout(r, 1000 * Math.pow(2, i)));
    }
  }
  throw new Error('withRetry: unreachable');
}
import {
  getDB,
  getPlayer,
  savePlayer,
  getRuns,
  saveRun,
  getRunById,
  getSavedRoutes,
  saveSavedRoute,
  getTerritoryPolygons,
  saveTerritory,
  deleteTerritory,
  getNutritionProfile,
  getUnsyncedNutritionEntries,
  markNutritionEntrySynced,
  type StoredRun,
  type StoredPlayer,
} from './store';
import type { TerritoryPolygon, TerritoryTier, RunnerRank } from '../types/game';
import { getProfile } from './profile';

/**
 * Returns the current user only if a valid local session exists.
 * Uses getSession() (no network call) then getUser() to validate.
 * Silently returns null when not logged in — avoids 403 console noise.
 */
async function getAuthenticatedUser() {
  const { data: { session } } = await supabase.auth.getSession();
  if (!session) return null;
  const { data: { user } } = await supabase.auth.getUser();
  return user ?? null;
}

// ----------------------------------------------------------------
// PROFILE SYNC
// ----------------------------------------------------------------

/** Push local player data to Supabase profiles table. */
export async function pushProfile(): Promise<void> {
  const [player, profile] = await Promise.all([getPlayer(), getProfile()]);
  if (!player) return;

  const user = await getAuthenticatedUser();
  if (!user) return;

  const { error } = await supabase.from('profiles').upsert({
    id: user.id,
    username: player.username,
    level: player.level,
    xp: player.xp,
    coins: player.coins,
    energy: player.energy,
    last_energy_regen: player.lastEnergyRegen ? new Date(player.lastEnergyRegen).toISOString() : new Date().toISOString(),
    total_territories_claimed: player.totalTerritoriesClaimed,
    // total_distance_km / total_runs deliberately NOT pushed (as of
    // lock_run_stat_columns.sql) — clubService.ts ranks club leaderboards on
    // total_distance_km with no other server recomputation, so a client-pushed
    // absolute value here was a direct leaderboard spoof. process-run-territory's
    // increment_run_stats RPC (service_role only) is now the sole writer, using its
    // own GPS-derived distance for each run. Pushing here would just be ignored by
    // protect_profile_columns, same as pace_*/streak_days below — not pushing at all
    // avoids the client ever reconstructing a stale value.
    // streak_days / last_run_date deliberately NOT pushed — streak_days feeds
    // process-run-territory's PACE streak bonus directly, so (like the pace_*
    // fields below) it's computed and persisted server-side from the profile's
    // own prior last_run_date, not trusted from the client. The client still
    // computes an optimistic streak locally for immediate UI feedback; pullProfile()
    // reads the authoritative value back. Pushing here would just be ignored by
    // the protect_profile_columns trigger, but not pushing at all matches the
    // pace_* precedent below and avoids the client ever reconstructing a stale value.
    // CRITICAL PATH: pace_balance / pace_total_earned / pace_weekly_earned are NEVER
    // pushed from the client. apply_pace_adjustment (20260515000059_territory_engine_rpcs.sql,
    // called from process-run-territory after every run) is the only thing allowed to
    // modify them server-side — it does an atomic increment. A client upsert of an
    // absolute value here would silently overwrite that atomic increment with a
    // client-reconstructed number — this was the actual mechanism behind the PACE
    // balance corruption a prior session's pullProfile() fix and diagnose_pace_ledger()
    // migration addressed. The client still computes and stores these locally (for the
    // offline-friendly immediate post-run UI) and PULLS the server's authoritative value
    // via pullProfile() — it must just never push them.
    // pace_weekly_reset_at and runner_rank are server-owned too: credit_pace_capped
    // resets the week and sets the rank. Pushing them let a client reset its own cap.
    // City rank / rival proximity — only sent once a location has actually been
    // captured (onboarding grant or post-run); never overwrites with an empty value.
    ...(player.lastKnownLocation && {
      last_known_location: `SRID=4326;POINT(${player.lastKnownLocation.lng} ${player.lastKnownLocation.lat})`,
    }),
    ...(player.country && { country: player.country }),
    // IANA zone so reminders, fading-zone alerts and campaigns arrive at the
    // runner's local hour (run_hourly_notifications). The server falls back
    // to UTC for anything it doesn't recognise.
    ...(deviceTimeZone() && { timezone: deviceTimeZone() }),
    // Onboarding prefs + biometrics
    ...(profile && {
      // Biometrics (migration 013)
      age:       profile.age       || null,
      gender:    profile.gender    || null,
      height_cm: profile.heightCm  || null,
      weight_kg: profile.weightKg  || null,
      // Training preferences
      experience_level: profile.experienceLevel,
      weekly_frequency: profile.weeklyFrequency,
      primary_goal: profile.primaryGoal,
      preferred_distance: profile.preferredDistance,
      playstyle: profile.playstyle ?? null,
      distance_unit: profile.distanceUnit,
      notifications_enabled: profile.notificationsEnabled,
      weekly_goal_km: profile.weeklyGoalKm,
      mission_difficulty: profile.missionDifficulty,
      onboarding_completed_at: new Date(profile.onboardingCompletedAt).toISOString(),
      phone: profile.phone ?? null,
    }),
    // Achievements (migration 019) — pushed with every profile sync
    unlocked_achievements: player.unlockedAchievements ?? [],
  }, { onConflict: 'id' });

  if (error) throw new Error(error.message);
}

/** Pull profile from Supabase and update local player record. */
export async function pullProfile(): Promise<void> {
  const user = await getAuthenticatedUser();
  if (!user) return;

  const { data, error } = await supabase
    .from('profiles')
    .select('*')
    .eq('id', user.id)
    .single();

  if (error || !data) return;

  const existing = await getPlayer();
  await savePlayer({
    id: existing?.id ?? user.id,
    username: data.username,
    level: data.level,
    xp: data.xp,
    coins: data.coins,
    energy: data.energy,
    lastEnergyRegen: (() => {
      const ms = new Date(data.last_energy_regen).getTime();
      // Guard against epoch-seconds values (would resolve to ~1970)
      return ms > 1e12 ? ms : ms * 1000;
    })(),
    totalDistanceKm: Number(data.total_distance_km),
    totalRuns: data.total_runs,
    totalTerritoriesClaimed: data.total_territories_claimed,
    totalEnemyCaptured: data.total_enemy_captured ?? 0,
    streakDays: data.streak_days,
    lastRunDate: data.last_run_date,
    lastLoginBonusDate: existing?.lastLoginBonusDate ?? null,
    // Union-merge: achievements from DB + local — never remove earned badges
    unlockedAchievements: Array.from(new Set([
      ...(existing?.unlockedAchievements ?? []),
      ...((data.unlocked_achievements as string[]) ?? []),
    ])),
    createdAt: new Date(data.created_at).getTime(),
    // CRITICAL: savePlayer() fully replaces the local record (IndexedDB/SQLite put,
    // not a partial merge) — any field left out here is silently wiped to undefined
    // on every pull. The PACE/rank fields below ARE pushed by pushProfile() above,
    // so they must be read back here or a login/postRunSync pull resets a player's
    // real balance to 0. Fields never pushed to the server (territoryScore,
    // largestTierAchieved, earnedAwardIds, pinnedRunId, lastKnownLocation) are kept
    // from the existing local record — the server has no authoritative value for them.
    paceBalance:        typeof data.pace_balance       === 'number' ? data.pace_balance       : (existing?.paceBalance       ?? 0),
    paceTotalEarned:    typeof data.pace_total_earned  === 'number' ? data.pace_total_earned   : (existing?.paceTotalEarned   ?? 0),
    paceWeeklyEarned:   typeof data.pace_weekly_earned === 'number' ? data.pace_weekly_earned  : (existing?.paceWeeklyEarned  ?? 0),
    paceWeeklyResetAt:  data.pace_weekly_reset_at ?? existing?.paceWeeklyResetAt ?? new Date().toISOString(),
    runnerRank:         (data.runner_rank as RunnerRank | undefined) ?? existing?.runnerRank ?? 'pacer',
    subscriptionTier:   typeof data.subscription_tier === 'string' ? data.subscription_tier : (existing?.subscriptionTier ?? 'free'),
    territoryScore:     existing?.territoryScore ?? 0,
    largestTierAchieved: existing?.largestTierAchieved,
    earnedAwardIds:      existing?.earnedAwardIds,
    pinnedRunId:         existing?.pinnedRunId,
    country:            (typeof data.country === 'string' ? data.country : null) ?? existing?.country ?? null,
    lastKnownLocation:   existing?.lastKnownLocation ?? null,
  } satisfies StoredPlayer);
}

// ----------------------------------------------------------------
// RUNS SYNC
// ----------------------------------------------------------------

/**
 * Ramer-Douglas-Peucker path simplification.
 * Reduces GPS point count before cloud upload while preserving route shape.
 * epsilon is in degrees (~0.00005 ≈ 5 m at equator — keeps ~50-150 points per run).
 */
function rdpSimplify(
  points: StoredRun['gpsPoints'],
  epsilon = 0.00005
): StoredRun['gpsPoints'] {
  if (points.length <= 2) return points;

  const start = points[0];
  const end = points[points.length - 1];
  const dx = end.lng - start.lng;
  const dy = end.lat - start.lat;
  const lineLen = Math.sqrt(dx * dx + dy * dy);

  let maxDist = 0;
  let maxIdx = 0;
  for (let i = 1; i < points.length - 1; i++) {
    const p = points[i];
    const dist = lineLen === 0
      ? Math.sqrt((p.lng - start.lng) ** 2 + (p.lat - start.lat) ** 2)
      : Math.abs(dy * p.lng - dx * p.lat + end.lng * start.lat - end.lat * start.lng) / lineLen;
    if (dist > maxDist) { maxDist = dist; maxIdx = i; }
  }

  if (maxDist > epsilon) {
    const left  = rdpSimplify(points.slice(0, maxIdx + 1), epsilon);
    const right = rdpSimplify(points.slice(maxIdx), epsilon);
    return [...left.slice(0, -1), ...right];
  }
  return [start, end];
}

// postRunSync (after finish) and initialSync (app launch / recovery) can be triggered
// concurrently — without this, both snapshot the same unsynced run before either marks
// it synced, and it gets pushed (and its territory processed) twice. Concurrent callers
// share the one in-flight push instead of starting a second one.
let _pushUnsyncedRunsInFlight: Promise<void> | null = null;

function deviceTimeZone(): string | null {
  try {
    const tz = Intl.DateTimeFormat().resolvedOptions().timeZone;
    return typeof tz === 'string' && tz.includes('/') ? tz : null;
  } catch {
    return null;
  }
}

/** Push all locally unsynced runs to Supabase. */
export async function pushUnsyncedRuns(): Promise<void> {
  if (_pushUnsyncedRunsInFlight) return _pushUnsyncedRunsInFlight;
  _pushUnsyncedRunsInFlight = pushUnsyncedRunsImpl().finally(() => {
    _pushUnsyncedRunsInFlight = null;
  });
  return _pushUnsyncedRunsInFlight;
}

async function pushUnsyncedRunsImpl(): Promise<void> {
  const user = await getAuthenticatedUser();
  if (!user) return;

  const allRuns = await getRuns();
  // Also retry runs that uploaded but were never scored: the server is
  // idempotent per run, so a retry can never pay twice.
  const unsynced = allRuns.filter(r => !r.synced || r.serverProcessed === false);
  if (unsynced.length === 0) return;

  for (const run of unsynced) {
    // Simplify GPS track before upload: keeps route shape but drops redundant
    // intermediate points (1800-point run → ~60-120 points, ~95% size reduction).
    const simplifiedPoints = rdpSimplify(run.gpsPoints);

    // A run already uploaded is only retried for scoring: runs are immutable
    // (there is no UPDATE policy), so re-sending it as an upsert hit RLS and
    // failed every later sync. First uploads use ON CONFLICT DO NOTHING so a
    // row that landed before a crash doesn't fail the same way.
    const { error } = run.synced ? { error: null } : await supabase.from('runs').upsert({
      id: run.id,
      user_id: user.id,
      activity_type: run.activityType,
      started_at: new Date(run.startTime).toISOString(),
      finished_at: new Date(run.endTime).toISOString(),
      distance_m: run.distanceMeters,
      duration_sec: run.durationSec,
      avg_pace: run.avgPace,
      gps_points: simplifiedPoints,
      territories_claimed: run.territoriesClaimed,
      territories_fortified: run.territoriesFortified,
      xp_earned: run.xpEarned ?? 0,
      coins_earned: run.coinsEarned ?? 0,
      enemy_captured: run.enemyCaptured ?? 0,
      pre_run_level: run.preRunLevel ?? 1,
    }, { onConflict: 'id', ignoreDuplicates: true });

    if (!error) {
      await saveRun({ ...run, synced: true, serverProcessed: run.serverProcessed === true ? true : false });
      // Invoke territory processing on the server (PostGIS steal/claim logic).
      // Runs fire-and-forget: failure here doesn't block the sync — PACE adjustment
      // from stolen zones will be credited on the next successful sync.
      try {
        const { data: session } = await supabase.auth.getSession();
        if (session.session) {
          const { data: result } = await supabase.functions.invoke('process-run-territory', {
            body: {
              runId:            run.id,
              userId:           user.id,
              gpsPoints:        run.gpsPoints,   // full original GPS trace (not simplified)
              activityType:     run.activityType,
              distanceKm:       run.distanceMeters / 1000,
              durationSec:      run.durationSec,
              clientPaceEarned: run.xpEarned ?? 0,
            },
          });
          if (result && typeof result.paceAdjustment === 'number') {
            const serverPace = result.paceAdjustment as number;
            const latestRun = (await getRunById(run.id)) ?? run;
            // Apply the correction once: after this the run carries the server's
            // number, so a retry or replay finds nothing left to correct.
            if (latestRun.serverProcessed !== true) {
              const delta = serverPace - (latestRun.xpEarned ?? 0);
              const player = await getPlayer();
              if (player && delta !== 0) {
                await savePlayer({
                  ...player,
                  paceBalance:      Math.max(0, (player.paceBalance      ?? 0) + delta),
                  paceTotalEarned:  Math.max(0, (player.paceTotalEarned  ?? 0) + delta),
                  paceWeeklyEarned: Math.max(0, (player.paceWeeklyEarned ?? 0) + delta),
                });
              }
              await saveRun({
                ...latestRun,
                synced: true,
                serverProcessed: true,
                xpEarned: serverPace,
                ...(typeof result.verifiedDistanceKm === 'number' && { verifiedDistanceKm: result.verifiedDistanceKm }),
                ...(typeof result.territoryAreaM2 === 'number' && { claimedAreaM2: result.claimedAreaM2 ?? 0, territoryAreaM2: result.territoryAreaM2 }),
                // What the server decided, for the run summary and the paywall moments.
                serverResult: {
                  newZones:            Number(result.newZonesClaimed) || 0,
                  stolenZones:         Number(result.rivalZonesStolen) || 0,
                  paceCapped:          result.paceCapped === true,
                  territoryCapReached: result.territoryCapReached === true,
                  streakDays:          Number(result.streakDays) || 0,
                },
              });
            }
            // The optimistic zone drawn at run end is replaced by the server's
            // real shape; keeping both counted the same ground twice.
            const optimistic = (await getTerritoryPolygons()).filter(t => t.runId === run.id && !t.synced);
            for (const t of optimistic) await deleteTerritory(t.id);
          }

          // Auto post-run debrief — fire-and-forget, non-blocking. Gated on
          // _aiCoachEnabled: see setAiCoachEnabled() above.
          // AI stays in Plus (PRD): only Plus runners get the auto debrief; the
          // server refuses it for everyone else anyway (ai-coach → 402).
          const tierForDebrief = (await getPlayer())?.subscriptionTier;
          if (_aiCoachEnabled && isPlus(tierForDebrief)) (async () => {
            try {
              const { data: debriefData } = await supabase.functions.invoke('ai-coach', {
                body: { feature: 'post_run', runId: run.id },
              });
              if (debriefData?.data) {
                const p = debriefData.data as { praise?: string; analysis?: string; suggestion?: string; recovery?: string };
                const content = [p.praise, p.analysis, p.suggestion, p.recovery].filter(Boolean).join('\n\n');
                if (content && user) {
                  await supabase.from('coach_messages').insert({
                    user_id:        user.id,
                    role:           'assistant',
                    content,
                    auto_triggered: true,
                    created_at:     new Date().toISOString(),
                  });
                }
              }
            } catch { /* non-critical */ }
          })();

          // Milestone card — check if largest tier improved
          ;(async () => {
            try {
              const localPolygons = await getTerritoryPolygons();
              if (localPolygons.length > 0) {
                const newLargestTier  = computeLargestTier(localPolygons) as TerritoryTier;
                const currentPlayer   = await getPlayer();
                const prevLargestTier = currentPlayer?.largestTierAchieved ?? 'patch';
                const tierOrder       = ['patch', 'block', 'district', 'quarter', 'domain'];
                if (tierOrder.indexOf(newLargestTier) > tierOrder.indexOf(prevLargestTier)) {
                  await supabase.from('feed_posts').insert({
                    user_id:           user.id,
                    post_type:         'milestone',
                    territory_tier:    newLargestTier,
                    territory_area_m2: localPolygons.reduce((s, p) => s + p.areaM2, 0),
                    runner_rank:       currentPlayer?.runnerRank ?? 'pacer',
                    pace_earned:       0,
                    distance_km:       0,
                    xp_earned:         0,
                    leveled_up:        false,
                  });
                  if (currentPlayer) {
                    await savePlayer({ ...currentPlayer, largestTierAchieved: newLargestTier });
                  }
                }
              }
            } catch { /* non-critical */ }
          })();
        }
      } catch {
        // Non-fatal — territory/PACE from steal will be re-evaluated on next sync
      }
    } else {
      // Throw so withRetry + postRunSync can set sync status to 'error' and surface
      // a "Could not upload run" message in the UI instead of silently discarding data.
      throw error;
    }
  }
}

/** Pull runs for the current user and cache locally (for history page). */
export async function pullRuns(limit = 50): Promise<void> {
  const user = await getAuthenticatedUser();
  if (!user) return;

  const { data, error } = await supabase
    .from('runs')
    .select('*')
    .eq('user_id', user.id)
    .order('started_at', { ascending: false })
    .limit(limit);

  if (error || !data) return;

  for (const row of data) {
    // Guard: never overwrite a locally-stored GPS trace with empty remote GPS.
    // This prevents a race condition where the Supabase row exists (default gps_points=[])
    // but the background push hasn't completed yet, causing the local trace to be lost.
    const local = await getRunById(row.id);
    const remoteGps = (row.gps_points as StoredRun['gpsPoints']) ?? [];
    const localGps = local?.gpsPoints ?? [];
    const gpsPoints = remoteGps.length >= 2 ? remoteGps : (localGps.length >= 2 ? localGps : remoteGps);

    await saveRun({
      id: row.id,
      activityType: row.activity_type,
      startTime: new Date(row.started_at).getTime(),
      endTime: new Date(row.finished_at).getTime(),
      distanceMeters: Number(row.distance_m),
      durationSec: row.duration_sec,
      avgPace: row.avg_pace,
      gpsPoints,
      territoriesClaimed: row.territories_claimed,
      territoriesFortified: row.territories_fortified,
      // Once the server has scored a run, its PACE and measured ground live on
      // the local record; the runs row still holds the app's first guess.
      xpEarned: local?.serverProcessed === true ? local.xpEarned : row.xp_earned,
      coinsEarned: row.coins_earned,
      enemyCaptured: row.enemy_captured ?? 0,
      preRunLevel: row.pre_run_level ?? 1,
      synced: true,
      serverProcessed: local?.serverProcessed,
      verifiedDistanceKm: local?.verifiedDistanceKm,
      territoryAreaM2: local?.territoryAreaM2,
      claimedAreaM2: local?.claimedAreaM2,
      serverResult: local?.serverResult,
      title: row.title ?? null,
      description: row.description ?? null,
      privateNotes: row.private_notes ?? null,
      perceivedEffort: row.perceived_effort ?? null,
      visibility: local?.visibility,
      excluded: row.excluded ?? false,
      photoPaths: row.photo_paths ?? [],
    });
  }
}

// ----------------------------------------------------------------
// TERRITORY SYNC (polygon corridors)
// ----------------------------------------------------------------

/**
 * Territory claims are now server-authoritative: process-run-territory (invoked from
 * pushUnsyncedRuns below) is the ONLY thing that inserts territory_polygons rows.
 * The client used to also push its own locally-built polygon for the same run under a
 * different id, which double-claimed area (and double-counted steals against rivals)
 * on every single run. RLS on territory_polygons no longer grants clients INSERT/UPDATE
 * for the same reason — see supabase/migrations for the corresponding policy change.
 *
 * The local polygon built by buildTerritoryPolygon() is still saved immediately
 * (useGameEngine.endRunSession) purely for optimistic on-device display; it is
 * superseded by pullTerritories() once the server's row comes back.
 */

/**
 * Pull the current user's own territory polygons from Supabase and reconcile the local
 * store: upserts server rows, and removes any locally-cached "synced" territory whose id
 * is no longer present server-side (e.g. fully captured by a rival) so a defeated player
 * doesn't keep seeing a zone they no longer own. Locally-unsynced records (optimistic,
 * not yet confirmed by the server) are never overwritten or deleted by this pass.
 */
export async function pullTerritories(): Promise<void> {
  const user = await getAuthenticatedUser();
  if (!user) return;

  const { data, error } = await supabase
    .from('territory_polygons')
    .select('id, run_id, owner_id, owner_name, polygon_coords, area_m2, freshness, last_defended_at, claimed_at, is_loop_fill, tier')
    .eq('owner_id', user.id)
    .limit(2000);

  if (error) return;

  const existing = await getTerritoryPolygons();
  const ownExisting = existing.filter(t => t.ownerId === user.id);
  const serverIds = new Set((data ?? []).map(row => row.id));

  for (const row of data ?? []) {
    const local = ownExisting.find(t => t.id === row.id);
    if (local && !local.synced) continue;

    const coords = (row.polygon_coords as [number, number][]) ?? [];
    if (coords.length < 4) continue;

    await saveTerritory({
      id:             row.id,
      runId:          row.run_id ?? '',
      ownerId:        row.owner_id,
      ownerName:      row.owner_name ?? '',
      polygon:        coords,
      areaM2:         Number(row.area_m2),
      freshness:      row.freshness ?? 100,
      lastDefendedAt: row.last_defended_at,
      claimedAt:      row.claimed_at,
      isLoopFill:     row.is_loop_fill ?? false,
      tier:           row.tier as TerritoryTier,
      synced:         true,
    });
  }

  const serverRunIds = new Set((data ?? []).map(row => row.run_id).filter(Boolean));
  const stale = ownExisting.filter(t =>
    (t.synced && !serverIds.has(t.id)) ||
    (!t.synced && t.runId && serverRunIds.has(t.runId)));
  for (const t of stale) {
    await deleteTerritory(t.id);
  }
}

/**
 * Fetches territory polygons visible within a map viewport bounding box.
 * Returns ALL owners' territories (for rival rendering).
 * Results are NOT persisted to local store — held in component state only.
 * Uses the get_map_polygons PostGIS RPC which filters by spatial intersection.
 */
export async function pullMapPolygons(bbox: {
  minLat: number; minLng: number; maxLat: number; maxLng: number;
}): Promise<TerritoryPolygon[]> {
  const { data, error } = await supabase.rpc('get_map_polygons', {
    min_lat: bbox.minLat,
    min_lng: bbox.minLng,
    max_lat: bbox.maxLat,
    max_lng: bbox.maxLng,
  });

  if (error || !data) return [];

  const rows = data as {
    id: string; owner_id: string; owner_name: string | null;
    area_m2: number; freshness: number; last_defended_at: string;
    is_loop_fill: boolean; tier: string; polygon_coords: [number, number][];
  }[];

  return rows
    .filter(r => r.polygon_coords && r.polygon_coords.length >= 4)
    .map(r => ({
      id:             r.id,
      runId:          '',
      ownerId:        r.owner_id,
      ownerName:      r.owner_name ?? '',
      polygon:        r.polygon_coords,
      areaM2:         Number(r.area_m2),
      freshness:      r.freshness ?? 100,
      lastDefendedAt: r.last_defended_at,
      claimedAt:      r.last_defended_at,
      isLoopFill:     r.is_loop_fill ?? false,
      tier:           r.tier as TerritoryTier,
      synced:         true,
    }));
}

// ----------------------------------------------------------------
// REALTIME SUBSCRIPTIONS
// ----------------------------------------------------------------

/**
 * Subscribe to live territory updates.
 *
 * Intentionally a no-op: territories are polygon corridors derived from GPS tracks and
 * stored locally in IndexedDB/SQLite. There is no server-side territory table to stream
 * from in real-time — territory state is pulled via pullTerritories() after each run.
 *
 * To re-enable real-time territory sync (e.g., for live attack notifications), wire a
 * Supabase Realtime subscription to the `territories` table here and update pullTerritories
 * to merge remote state with the local cache.
 */
export function subscribeTerritories(
  _onUpdate: (territory: TerritoryPolygon) => void
): () => void {
  return () => {};
}

/**
 * Subscribe to lobby messages for a given lobby ID.
 * Returns unsubscribe function.
 */
export function subscribeLobbyMessages(
  lobbyId: string,
  onMessage: (msg: { id: string; userId: string; content: string; createdAt: string }) => void
): () => void {
  const channel = supabase
    .channel(`lobby-${lobbyId}`)
    .on(
      'postgres_changes',
      {
        event: 'INSERT',
        schema: 'public',
        table: 'lobby_messages',
        filter: `lobby_id=eq.${lobbyId}`,
      },
      (payload) => {
        const row = payload.new as { id: string; user_id: string; content: string; created_at: string };
        onMessage({ id: row.id, userId: row.user_id, content: row.content, createdAt: row.created_at });
      }
    )
    .subscribe();

  return () => { supabase.removeChannel(channel); };
}

// ----------------------------------------------------------------
// SAVED ROUTES SYNC
// ----------------------------------------------------------------

/** Push unsynced saved routes to Supabase. */
export async function pushSavedRoutes(): Promise<void> {
  const user = await getAuthenticatedUser();
  if (!user) return;

  const all = await getSavedRoutes();
  const unsynced = all.filter(r => !r.synced);
  if (unsynced.length === 0) return;

  for (const route of unsynced) {
    const { error } = await supabase.from('saved_routes').upsert({
      id: route.id,
      user_id: user.id,
      name: route.name,
      emoji: route.emoji,
      distance_m: route.distanceM,
      duration_sec: route.durationSec,
      gps_points: route.gpsPoints,
      is_public: route.isPublic,
      source_run_id: route.sourceRunId,
    }, { onConflict: 'id' });

    if (!error) {
      await saveSavedRoute({ ...route, synced: true });
    } else {
      console.warn('[sync] Failed to push saved route', route.id, error.message);
    }
  }
}

/** Pull user's saved routes from Supabase. */
export async function pullSavedRoutes(): Promise<void> {
  const user = await getAuthenticatedUser();
  if (!user) return;

  const { data, error } = await supabase
    .from('saved_routes')
    .select('id, name, emoji, distance_m, duration_sec, gps_points, is_public, source_run_id, created_at')
    .eq('user_id', user.id)
    .order('created_at', { ascending: false });

  if (error || !data) return;

  for (const row of data) {
    await saveSavedRoute({
      id: row.id,
      name: row.name,
      emoji: row.emoji,
      distanceM: Number(row.distance_m),
      durationSec: row.duration_sec,
      gpsPoints: (row.gps_points as { lat: number; lng: number }[]) ?? [],
      isPublic: row.is_public,
      sourceRunId: row.source_run_id,
      synced: true,
      createdAt: new Date(row.created_at).getTime(),
    });
  }
}

/** Find public routes near a position via PostGIS RPC. */
export interface NearbyRoute {
  id: string;
  name: string;
  emoji: string;
  distanceM: number;
  durationSec: number | null;
  gpsPoints: { lat: number; lng: number }[];
  username: string;
  distM: number;
}

export async function findRoutesNearby(
  lng: number,
  lat: number,
  radiusM = 5000
): Promise<NearbyRoute[]> {
  const { data, error } = await supabase.rpc('find_routes_nearby', {
    p_lng: lng,
    p_lat: lat,
    p_radius_m: radiusM,
  });

  if (error || !data) return [];

  interface RouteNearbyRow {
    id: string; name: string; emoji: string; distance_m: number;
    duration_sec: number | null;
    gps_points: { lat: number; lng: number }[];
    username: string; dist_m: number;
  }

  return (data as RouteNearbyRow[]).map((r): NearbyRoute => ({
    id: r.id,
    name: r.name,
    emoji: r.emoji,
    distanceM: Number(r.distance_m),
    durationSec: r.duration_sec,
    gpsPoints: r.gps_points ?? [],
    username: r.username,
    distM: r.dist_m,
  }));
}

// ----------------------------------------------------------------
// NUTRITION SYNC
// ----------------------------------------------------------------

/** Push unsynced local nutrition log entries to Supabase. */
export async function pushNutritionLogs(): Promise<void> {
  const user = await getAuthenticatedUser();
  if (!user) return;

  const unsynced = await getUnsyncedNutritionEntries();
  if (unsynced.length === 0) return;

  // Each entry gets a stable remote UUID the first time it syncs (reused on retry) —
  // using the local autoincrement id directly as the remote PK let two devices that
  // both start counting from 1 collide and silently drop each other's entries.
  const withRemoteId = unsynced.map(e => ({ entry: e, remoteId: e.remoteId ?? crypto.randomUUID() }));

  const { error } = await supabase.from('nutrition_logs').upsert(
    withRemoteId.map(({ entry: e, remoteId }) => ({
      id: remoteId,
      user_id: user.id,
      log_date: e.date,
      meal: e.meal,
      name: e.name,
      kcal: e.kcal,
      protein_g: e.proteinG,
      carbs_g: e.carbsG,
      fat_g: e.fatG,
      serving_size: e.servingSize,
      source: e.source,
      logged_at: new Date(e.loggedAt).toISOString(),
      xp_awarded: e.xpAwarded,
    })),
    { onConflict: 'id' }
  );

  if (!error) {
    for (const { entry: e, remoteId } of withRemoteId) {
      if (e.id !== undefined) await markNutritionEntrySynced(e.id as number, remoteId);
    }
  } else {
    console.warn('[sync] pushNutritionLogs failed:', error.message);
  }
}

/** Push the local nutrition profile (setup data) to Supabase. */
export async function pushNutritionProfile(): Promise<void> {
  const user = await getAuthenticatedUser();
  if (!user) return;

  const np = await getNutritionProfile();
  if (!np) return;

  const { error } = await supabase.from('nutrition_profiles').upsert({
    user_id: user.id,
    goal: np.goal,
    activity_level: np.activityLevel,
    diet: np.diet,
    weight_kg: np.weightKg,
    height_cm: np.heightCm,
    age: np.age,
    sex: np.sex,
    daily_goal_kcal: np.dailyGoalKcal,
    protein_goal_g: np.proteinGoalG,
    carbs_goal_g: np.carbsGoalG,
    fat_goal_g: np.fatGoalG,
    updated_at: new Date().toISOString(),
  }, { onConflict: 'user_id' });

  if (error) console.warn('[sync] pushNutritionProfile failed:', error.message);
}

// ----------------------------------------------------------------
// FULL SYNC — call on app boot after auth
// ----------------------------------------------------------------

/** Run all pulls on startup. Non-fatal — individual failures are swallowed. */
export async function initialSync(): Promise<void> {
  await Promise.allSettled([
    pullProfile(),
    pullRuns(),
    pullTerritories(),
    pullSavedRoutes(),
  ]);
  // Push any runs/routes/nutrition data recorded offline
  await Promise.allSettled([
    pushUnsyncedRuns(),
    pushSavedRoutes(),
    pushNutritionLogs(),
    pushNutritionProfile(),
  ]);
}

/** Call after finishing a run to persist everything. Returns {ok:false} on failure (run is safe locally). */
export async function postRunSync(): Promise<{ ok: boolean }> {
  setSyncStatus('syncing');
  try {
    // 1. Push run first — DB trigger fires, increments total_runs / total_distance_km
    await withRetry(() => pushUnsyncedRuns());
    // 2. Push saved routes (non-blocking for XP correctness, but keep sequential)
    await pushSavedRoutes();
    // 3. Push local XP / coins / diamonds before any pull can overwrite them
    await withRetry(() => pushProfile());
    // 4. Brief settle window so the DB trigger result is visible on next read
    await new Promise<void>(r => setTimeout(r, 400));
    // 5. Pull canonical server state (correct XP, distance, streaks from DB trigger)
    await pullProfile();
    // 6. Refresh run list
    await pullRuns();
    // 7. Pull the territory row process-run-territory just wrote server-side
    //    (the server is the sole claim path — see pullTerritories' doc comment)
    await pullTerritories();
    // 8. Sync any new nutrition entries logged during the run (XP food bonuses etc.)
    await pushNutritionLogs();
    setSyncStatus('idle');
    return { ok: true };
  } catch (err) {
    console.error('[sync] postRunSync failed:', err);
    // navigator.onLine is undefined in React Native (not just false) — only report
    // 'offline' when we positively know the device is offline, so real server/RLS
    // errors surface as 'error' instead of being masked as an unretriable "offline".
    setSyncStatus(typeof navigator !== 'undefined' && navigator.onLine === false ? 'offline' : 'error');
    // Don't attempt a pull on error — stale local state is safer than an overwritten local
    return { ok: false };
  }
}

// ----------------------------------------------------------------
// FEED
// ----------------------------------------------------------------

export async function createFeedPost(
  runId: string,
  distanceKm: number,
  territoriesClaimed: number,
  opts?: {
    paceEarned?: number;
    territoryTier?: string | null;
    territoryAreaM2?: number | null;
    runnerRank?: string;
    content?: string;
    durationSec?: number;
    avgPace?: string;
    activityType?: string;
    routePoints?: { lat: number; lng: number }[];
  },
) {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return;

  // The full route goes to the server, which trims it to the runner's map
  // visibility before storing (feed_posts_blur_route). Trimming here as well
  // would trim twice: the server measures from whatever ends it receives.
  const { error } = await supabase.from('feed_posts').insert({
    user_id:             user.id,
    run_id:              runId,
    distance_km:         distanceKm,
    territories_claimed: territoriesClaimed,
    content:             opts?.content ?? null,
    pace_earned:         opts?.paceEarned ?? 0,
    territory_tier:      opts?.territoryTier ?? null,
    territory_area_m2:   opts?.territoryAreaM2 ?? null,
    runner_rank:         opts?.runnerRank ?? 'pacer',
    duration_sec:        opts?.durationSec ?? 0,
    avg_pace:            opts?.avgPace ?? '',
    activity_type:       opts?.activityType ?? 'run',
    route_points:        opts?.routePoints ?? null,
  });
  if (error) console.warn('[sync] feed post failed:', error.message);
}

// ----------------------------------------------------------------
// LEADERBOARD
// ----------------------------------------------------------------

export async function fetchLeaderboard() {
  const { data, error } = await supabase
    .from('leaderboard_weekly')
    .select('*')
    .order('rank', { ascending: true })
    .limit(100);

  if (error) throw error;
  return data;
}

// ----------------------------------------------------------------
// MISSIONS
// ----------------------------------------------------------------

export async function upsertMissionProgress(
  missionId: string,
  missionType: string,
  currentValue: number,
  completed: boolean,
  claimed: boolean,
  expiresAt: number
) {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return;

  const { error } = await supabase.from('mission_progress').upsert({
    id: missionId,
    user_id: user.id,
    mission_type: missionType,
    current_value: currentValue,
    completed,
    claimed,
    expires_at: new Date(expiresAt).toISOString(),
  }, { onConflict: 'id,user_id' });
  if (error) console.warn('[sync] mission progress failed:', error.message);
}

export async function fetchMissionProgress(missionIds: string[]) {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return [];

  const { data, error } = await supabase
    .from('mission_progress')
    .select('*')
    .eq('user_id', user.id)
    .in('id', missionIds);

  if (error) return [];
  return data;
}

// ----------------------------------------------------------------
// DATABASE helper — safe select from IndexedDB for offline reads
// ----------------------------------------------------------------
export { getDB };
