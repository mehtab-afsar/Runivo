import React, { useRef, useState, useMemo } from 'react';
import { View, Text, Pressable, StyleSheet, Linking } from 'react-native';
import { useNavigation, useRoute, type RouteProp } from '@react-navigation/native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { MapPin } from 'phosphor-react-native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { useTheme, useIsDark, Fonts, type AppColors } from '@theme';
import { territoryPalette, territoryLayerStyles } from '@theme/territory';
import type { RootStackParamList } from '@navigation/AppNavigator';
import { useTerritoryMap } from '../hooks/useTerritoryMap';
import { TerritoryFilterChips } from '../components/TerritoryFilterChips';
import { TerritoryBottomSheet } from '../components/TerritoryBottomSheet';
import { MapSearchBar } from '../components/MapSearchBar';

import { MAP_STYLES } from '@theme/maps';
import ML from '@maplibre/maplibre-react-native';
import { useRunivoMapStyle } from '@theme/runivoMapStyle';

type Nav = NativeStackNavigationProp<RootStackParamList>;

export default function TerritoryMapScreen() {
  const C      = useTheme();
  const ss     = useMemo(() => mkStyles(C), [C]);
  const insets = useSafeAreaInsets();
  const navigation = useNavigation<Nav>();
  const route  = useRoute<RouteProp<RootStackParamList, 'TerritoryMap'>>();
  const initialFilter = route.params?.initialFilter;

  const {
    ownPolygons, rivalPolygons, geoJSON, activeFilter, setActiveFilter,
    selectedPolygon, setSelectedPolygon, stats, isLoadingRivals,
    defaultCenter, handleBboxChange, locationStatus, requestLocation,
  } = useTerritoryMap(initialFilter);
  const [locationCardDismissed, setLocationCardDismissed] = useState(false);
  const showLocationCard = locationStatus !== 'granted' && !locationCardDismissed;

  const cameraRef = useRef<any>(null);
  const isDark = useIsDark();
  const zoneStyles = useMemo(() => territoryLayerStyles(territoryPalette(isDark)), [isDark]);
  // Dark mode opens on the dark basemap; the picker still cycles every style.
  const [styleIdx] = useState(() => (isDark ? 1 : 0));
  const baseStyle = useRunivoMapStyle(MAP_STYLES[styleIdx].url);
  // Follows the screen's own permission state, so the dot appears as soon as
  // the runner allows location from the card below.
  const locationGranted = locationStatus === 'granted';



  const selectedFilter: any = selectedPolygon
    ? ['==', ['get', 'id'], selectedPolygon.id]
    : ['==', ['get', 'id'], ''];

  function handleRegionChange(feature: any) {
    const bounds = feature?.properties?.visibleBounds;
    if (!bounds) return;
    // MapLibre RN's visibleBounds is [northEast, southWest], not [min, max] — treating
    // it as [min, max] made minLat > maxLat, so the rival-polygon bbox filter could
    // never match and rivals never rendered. Math.min/max over both corners is
    // correct regardless of corner order.
    const [c0, c1] = bounds;
    handleBboxChange({
      minLng: Math.min(c0[0], c1[0]), minLat: Math.min(c0[1], c1[1]),
      maxLng: Math.max(c0[0], c1[0]), maxLat: Math.max(c0[1], c1[1]),
    });
  }

  function handlePolygonPress(e: any) {
    const feat = e.features?.[0];
    if (!feat) { setSelectedPolygon(null); return; }
    const p = feat.properties as any;
    const ring: [number, number][] = feat.geometry?.coordinates?.[0] ?? [];
    const center: [number, number] | undefined = ring.length
      ? [ring.reduce((a, c) => a + c[0], 0) / ring.length, ring.reduce((a, c) => a + c[1], 0) / ring.length]
      : undefined;
    setSelectedPolygon({
      id: p.id, ownerId: p.ownerId, ownerName: p.ownerName,
      isOwn: p.isOwn, freshness: p.freshness, tier: p.tier,
      areaM2: p.areaM2, claimedAt: p.claimedAt, isLoopFill: p.isLoopFill, center, ring,
    });
  }

  const isEmpty = ownPolygons.length === 0 && rivalPolygons.length === 0 && !isLoadingRivals;

  return (
    <View style={ss.container}>
      <ML.MapView
        style={ss.map}
        mapStyle={baseStyle}
        onRegionDidChange={handleRegionChange}
        logoEnabled={false}
        attributionEnabled
      >
        <ML.Camera
          ref={cameraRef}
          centerCoordinate={defaultCenter}
          zoomLevel={13}
          animationDuration={0}
        />
        {/* Native dot: MapLibre's JS-animated puck breaks on React Native 0.83 (see patches/). */}
        {locationGranted && <ML.UserLocation visible renderMode="native" />}
        {geoJSON.features.length > 0 && (
          <ML.ShapeSource id="territories" shape={geoJSON} onPress={handlePolygonPress}>
            <ML.LineLayer id="territory-new-halo" style={zoneStyles.newHalo as any} filter={zoneStyles.newFilter as any} />
            <ML.FillLayer id="territory-fill" style={zoneStyles.fill as any} />
            <ML.LineLayer id="territory-line" style={zoneStyles.line as any} />
            <ML.LineLayer id="territory-fading" style={zoneStyles.fadingLine as any} filter={zoneStyles.fadingFilter as any} />
            <ML.LineLayer id="territory-selected" style={zoneStyles.selectedLine as any} filter={selectedFilter} />
          </ML.ShapeSource>
        )}
      </ML.MapView>

      <View style={[ss.topOverlay, { top: Math.max(18, insets.top) }]}>
        <View style={ss.searchRow}>
          <View style={{ flex: 1 }}>
            <MapSearchBar
              onFound={coord => cameraRef.current?.setCamera({ centerCoordinate: coord, zoomLevel: 15, animationDuration: 900 })}
            />
          </View>
        </View>
        <TerritoryFilterChips
          activeFilter={activeFilter}
          counts={{ mine: ownPolygons.length, rivals: rivalPolygons.length, stale: stats.staleCount }}
          onSelect={setActiveFilter}
        />
      </View>

      {showLocationCard && (
        <View style={ss.emptyState}>
          <MapPin size={40} color={C.red} weight="fill" />
          <Text style={ss.emptyTitle}>See the zones on your streets</Text>
          <Text style={ss.emptyBody}>
            Runivo uses your location to show the zones and rivals around you, and to claim ground when you run.
            It's only used while the app is open.
          </Text>
          {locationStatus === 'denied' ? (
            <Pressable style={ss.emptyBtn} onPress={() => Linking.openSettings()}>
              <Text style={ss.emptyBtnText}>Open Settings</Text>
            </Pressable>
          ) : (
            <Pressable style={ss.emptyBtn} onPress={requestLocation}>
              <Text style={ss.emptyBtnText}>Turn on location</Text>
            </Pressable>
          )}
          <Pressable onPress={() => setLocationCardDismissed(true)} hitSlop={8}>
            <Text style={ss.notNow}>Not now</Text>
          </Pressable>
        </View>
      )}

      {isEmpty && !showLocationCard && (
        <View style={ss.emptyState}>
          <MapPin size={40} color={C.red} weight="fill" />
          <Text style={ss.emptyTitle}>No zones yet</Text>
          <Text style={ss.emptyBody}>Run a loop to claim the ground inside it. Any run of 200 m or more claims the street you ran.</Text>
          <Pressable style={ss.emptyBtn}
            onPress={() => navigation.navigate('Main', { screen: 'Run' })}>
            <Text style={ss.emptyBtnText}>Start a run</Text>
          </Pressable>
        </View>
      )}

      {/* As in the mock: no stats strip; tapping a zone opens its sheet. */}
      {selectedPolygon && (
        <TerritoryBottomSheet
          polygon={selectedPolygon}
          onClose={() => setSelectedPolygon(null)}
          onDefend={(name) => {
            const z = selectedPolygon;
            setSelectedPolygon(null);
            // Start a run aimed at this zone: direction and distance on the live screen.
            if (z.ring && z.ring.length >= 4) {
              navigation.navigate('ActiveRun', {
                autoStart: false, activityType: 'run',
                targetZone: { id: z.id, name, ring: z.ring, mode: z.isOwn ? 'defend' : 'attack' },
              });
            } else {
              navigation.navigate('Main', { screen: 'Run' });
            }
          }}
        />
      )}
    </View>
  );
}

function mkStyles(C: AppColors) {
  return StyleSheet.create({
    container:    { flex: 1, backgroundColor: C.bg },
    map:          { position: 'absolute', top: 0, left: 0, right: 0, bottom: 0 },
    topOverlay:   { position: 'absolute', left: 14, right: 14, gap: 10 },
    searchRow:    { flexDirection: 'row', alignItems: 'center', gap: 8 },
    styleBtn:     { width: 48, height: 48, borderRadius: 24, backgroundColor: C.card, alignItems: 'center', justifyContent: 'center', shadowColor: '#000', shadowOpacity: 0.08, shadowRadius: 8, shadowOffset: { width: 0, height: 2 }, elevation: 3 },
    emptyState:   { position: 'absolute', left: 18, right: 18, top: '30%', alignItems: 'center', backgroundColor: C.card, borderRadius: 20, gap: 8, paddingVertical: 24, paddingHorizontal: 22, shadowColor: '#000', shadowOpacity: 0.10, shadowRadius: 20, shadowOffset: { width: 0, height: 6 }, elevation: 8 },
    emptyTitle:   { fontFamily: Fonts.bold, fontSize: 22, lineHeight: 24, letterSpacing: -0.5, color: C.t1, textAlign: 'center' },
    emptyBody:    { fontFamily: Fonts.regular, fontSize: 13.5, lineHeight: 19, color: C.t2, textAlign: 'center', marginBottom: 8 },
    emptyBtn:     { backgroundColor: C.red, borderRadius: 999, height: 46, justifyContent: 'center', paddingHorizontal: 26 },
    emptyBtnText: { fontFamily: Fonts.semiBold, fontSize: 15, color: C.alwaysLight },
    notNow:       { fontFamily: Fonts.medium, fontSize: 14, color: C.t2, marginTop: 4 },
  });
}
