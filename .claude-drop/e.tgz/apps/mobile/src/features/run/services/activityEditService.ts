import { supabase } from '@shared/services/supabase';
import { getRunById, saveRun, deleteRun } from '@shared/services/store';

/** Who can see an activity (20261112000004_activity_edit.sql). */
export type Audience = 'everyone' | 'followers' | 'only_me';

export const AUDIENCES: { id: Audience; label: string; sub: string }[] = [
  { id: 'everyone',  label: 'Everyone',  sub: 'Anyone on Runivo, including Discover' },
  { id: 'followers', label: 'Followers', sub: 'Only people who follow you' },
  { id: 'only_me',   label: 'Only you',  sub: 'Nobody else sees it' },
];

export interface ActivityEdit {
  title: string;
  description: string;
  privateNotes: string;
  perceivedEffort: number | null;
  visibility: Audience;
}

export async function fetchActivityEdit(runId: string): Promise<ActivityEdit> {
  const local = await getRunById(runId);
  const [{ data: run }, { data: post }] = await Promise.all([
    supabase.from('runs').select('title, description, private_notes, perceived_effort').eq('id', runId).maybeSingle(),
    supabase.from('feed_posts').select('visibility').eq('run_id', runId).limit(1).maybeSingle(),
  ]);
  return {
    title:           (run?.title as string | null) ?? local?.title ?? '',
    description:     (run?.description as string | null) ?? local?.description ?? '',
    privateNotes:    (run?.private_notes as string | null) ?? local?.privateNotes ?? '',
    perceivedEffort: (run?.perceived_effort as number | null) ?? local?.perceivedEffort ?? null,
    visibility:      ((post?.visibility as Audience | null) ?? local?.visibility ?? 'everyone'),
  };
}

/** Saves on the server, then on the device. Throws if the run has not reached the server yet. */
export async function saveActivityEdit(runId: string, e: ActivityEdit): Promise<void> {
  const { data, error } = await supabase.rpc('update_activity', {
    p_run_id: runId,
    p_title: e.title,
    p_description: e.description,
    p_visibility: e.visibility,
    p_perceived_effort: e.perceivedEffort,
    p_private_notes: e.privateNotes,
  });
  if (error) throw new Error(error.message);
  if (data !== true) throw new Error('not_synced');
  const local = await getRunById(runId);
  if (local) {
    await saveRun({
      ...local,
      title: e.title.trim() || null,
      description: e.description.trim() || null,
      privateNotes: e.privateNotes.trim() || null,
      perceivedEffort: e.perceivedEffort,
      visibility: e.visibility,
    });
  }
}

/** Removes the activity and its post. Zones it claimed and PACE it earned stay. */
export async function deleteActivity(runId: string): Promise<void> {
  const local = await getRunById(runId);
  if (local?.synced !== false) {
    const { error } = await supabase.rpc('delete_activity', { p_run_id: runId });
    if (error) throw new Error(error.message);
  }
  await deleteRun(runId);
}

export async function fetchDefaultAudience(): Promise<Audience> {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return 'everyone';
  const { data } = await supabase.from('profiles').select('default_activity_visibility').eq('id', user.id).maybeSingle();
  return (data?.default_activity_visibility as Audience | null) ?? 'everyone';
}

export async function saveDefaultAudience(a: Audience): Promise<void> {
  const { error } = await supabase.rpc('set_default_activity_visibility', { p_visibility: a });
  if (error) throw new Error(error.message);
}
