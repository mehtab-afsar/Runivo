/**
 * Edit an activity, Strava-style: title, description, how it felt, private
 * notes, who can see it, and delete.
 */
import React, { useEffect, useMemo, useState } from 'react';
import {
  Modal, View, Text, TextInput, Pressable, ScrollView, StyleSheet, ActivityIndicator, Alert,
  KeyboardAvoidingView, Platform,
} from 'react-native';
import { X, Check, Trash, LockSimple } from 'phosphor-react-native';
import { useTheme, Fonts, type AppColors } from '@theme';
import {
  AUDIENCES, fetchActivityEdit, saveActivityEdit, deleteActivity, type ActivityEdit,
} from '../services/activityEditService';

const EFFORT_WORDS = ['', 'Very easy', 'Easy', 'Easy', 'Moderate', 'Moderate', 'Hard', 'Hard', 'Very hard', 'Very hard', 'Max'];

interface Props {
  visible: boolean;
  runId: string;
  /** Shown as the title's placeholder, e.g. "Morning run". */
  defaultTitle: string;
  onClose: () => void;
  onSaved: (e: ActivityEdit) => void;
  onDeleted: () => void;
}

export default function EditActivitySheet({ visible, runId, defaultTitle, onClose, onSaved, onDeleted }: Props) {
  const C = useTheme();
  const s = useMemo(() => mkStyles(C), [C]);
  const [form, setForm] = useState<ActivityEdit | null>(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!visible) return;
    setForm(null);
    fetchActivityEdit(runId)
      .then(setForm)
      .catch(() => setForm({ title: '', description: '', privateNotes: '', perceivedEffort: null, visibility: 'everyone' }));
  }, [visible, runId]);

  const set = (patch: Partial<ActivityEdit>) => setForm(f => (f ? { ...f, ...patch } : f));

  const save = async () => {
    if (!form) return;
    setSaving(true);
    try {
      await saveActivityEdit(runId, form);
      onSaved(form);
      onClose();
    } catch (e) {
      Alert.alert(
        "Couldn't save",
        e instanceof Error && e.message === 'not_synced'
          ? 'This activity is still uploading. Try again in a moment.'
          : 'Check your connection and try again.',
      );
    } finally {
      setSaving(false);
    }
  };

  const confirmDelete = () => {
    Alert.alert(
      'Delete this activity?',
      "It's removed from your history and the feed. Zones it claimed and PACE it earned stay yours. This can't be undone.",
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete', style: 'destructive', onPress: async () => {
            setSaving(true);
            try { await deleteActivity(runId); onClose(); onDeleted(); }
            catch { Alert.alert("Couldn't delete", 'Check your connection and try again.'); }
            finally { setSaving(false); }
          },
        },
      ],
    );
  };

  return (
    <Modal visible={visible} animationType="slide" presentationStyle="pageSheet" onRequestClose={onClose}>
      <KeyboardAvoidingView style={s.root} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <View style={s.header}>
          <Pressable onPress={onClose} style={s.iconBtn} hitSlop={8} accessibilityRole="button" accessibilityLabel="Close">
            <X size={18} color={C.t1} weight="regular" />
          </Pressable>
          <Text style={s.title}>Edit activity</Text>
          <Pressable onPress={save} style={[s.saveBtn, (!form || saving) && { opacity: 0.5 }]} disabled={!form || saving} accessibilityRole="button">
            {saving ? <ActivityIndicator size="small" color={C.bg} /> : <Check size={16} color={C.bg} weight="bold" />}
            <Text style={s.saveTxt}>Save</Text>
          </Pressable>
        </View>

        {!form ? (
          <View style={s.center}><ActivityIndicator color={C.t2} /></View>
        ) : (
          <ScrollView contentContainerStyle={s.scroll} keyboardShouldPersistTaps="handled">
            <Text style={s.label}>Title</Text>
            <TextInput
              style={s.input}
              value={form.title}
              onChangeText={t => set({ title: t })}
              placeholder={defaultTitle}
              placeholderTextColor={C.t3}
              maxLength={80}
              returnKeyType="done"
            />

            <Text style={s.label}>Description</Text>
            <TextInput
              style={[s.input, s.multi]}
              value={form.description}
              onChangeText={t => set({ description: t })}
              placeholder="How did it go? Shown with your post."
              placeholderTextColor={C.t3}
              maxLength={2000}
              multiline
            />

            <Text style={s.label}>How did it feel?</Text>
            <View style={s.effortRow}>
              {Array.from({ length: 10 }, (_, i) => i + 1).map(n => {
                const on = form.perceivedEffort === n;
                return (
                  <Pressable
                    key={n}
                    style={[s.effort, on && s.effortOn]}
                    onPress={() => set({ perceivedEffort: on ? null : n })}
                    accessibilityRole="button"
                    accessibilityLabel={`Effort ${n} of 10, ${EFFORT_WORDS[n]}`}
                    accessibilityState={{ selected: on }}
                  >
                    <Text style={[s.effortTxt, on && s.effortTxtOn]}>{n}</Text>
                  </Pressable>
                );
              })}
            </View>
            <Text style={s.hint}>{form.perceivedEffort ? `${form.perceivedEffort}/10 · ${EFFORT_WORDS[form.perceivedEffort]}` : 'Optional. Only you see it.'}</Text>

            <View style={s.labelRow}>
              <Text style={s.label}>Private notes</Text>
              <LockSimple size={12} color={C.t3} weight="bold" />
            </View>
            <TextInput
              style={[s.input, s.multi]}
              value={form.privateNotes}
              onChangeText={t => set({ privateNotes: t })}
              placeholder="Shoes, aches, how you slept. Only you see these."
              placeholderTextColor={C.t3}
              maxLength={2000}
              multiline
            />

            <Text style={s.label}>Who can see this activity</Text>
            <View style={s.card}>
              {AUDIENCES.map((a, i) => {
                const on = form.visibility === a.id;
                return (
                  <Pressable
                    key={a.id}
                    style={[s.audRow, i > 0 && s.audBorder]}
                    onPress={() => set({ visibility: a.id })}
                    accessibilityRole="radio"
                    accessibilityState={{ checked: on }}
                  >
                    <View style={{ flex: 1 }}>
                      <Text style={s.audTitle}>{a.label}</Text>
                      <Text style={s.audSub}>{a.sub}</Text>
                    </View>
                    <View style={[s.radio, on && s.radioOn]}>{on && <View style={s.radioDot} />}</View>
                  </Pressable>
                );
              })}
            </View>

            <Pressable style={s.delete} onPress={confirmDelete} disabled={saving} accessibilityRole="button">
              <Trash size={16} color={C.red} weight="regular" />
              <Text style={s.deleteTxt}>Delete activity</Text>
            </Pressable>
          </ScrollView>
        )}
      </KeyboardAvoidingView>
    </Modal>
  );
}

function mkStyles(C: AppColors) {
  return StyleSheet.create({
    root:     { flex: 1, backgroundColor: C.bg },
    header:   { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 18, paddingVertical: 14 },
    iconBtn:  { width: 36, height: 36, borderRadius: 18, backgroundColor: C.card, alignItems: 'center', justifyContent: 'center' },
    title:    { fontFamily: Fonts.semiBold, fontSize: 17, color: C.t1 },
    saveBtn:  { flexDirection: 'row', alignItems: 'center', gap: 6, height: 34, paddingHorizontal: 14, borderRadius: 17, backgroundColor: C.t1 },
    saveTxt:  { fontFamily: Fonts.semiBold, fontSize: 13.5, color: C.bg },
    center:   { flex: 1, alignItems: 'center', justifyContent: 'center' },
    scroll:   { paddingHorizontal: 18, paddingBottom: 48 },
    label:    { fontFamily: Fonts.medium, fontSize: 12, color: C.t2, marginTop: 18, marginBottom: 8 },
    labelRow: { flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 18, marginBottom: 8 },
    input:    { backgroundColor: C.card, borderRadius: 12, paddingHorizontal: 14, paddingVertical: 12, fontFamily: Fonts.regular, fontSize: 15, color: C.t1 },
    multi:    { minHeight: 88, textAlignVertical: 'top' },
    effortRow:{ flexDirection: 'row', gap: 4 },
    effort:   { flex: 1, height: 36, borderRadius: 8, backgroundColor: C.card, alignItems: 'center', justifyContent: 'center' },
    effortOn: { backgroundColor: C.red },
    effortTxt:{ fontFamily: Fonts.semiBold, fontSize: 13, color: C.t2 },
    effortTxtOn: { color: C.alwaysLight },
    hint:     { fontFamily: Fonts.regular, fontSize: 12, color: C.t3, marginTop: 6 },
    card:     { backgroundColor: C.card, borderRadius: 16 },
    audRow:   { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 14, paddingVertical: 12 },
    audBorder:{ borderTopWidth: 1, borderTopColor: C.border },
    audTitle: { fontFamily: Fonts.semiBold, fontSize: 14, color: C.t1 },
    audSub:   { fontFamily: Fonts.regular, fontSize: 12, color: C.t2, marginTop: 2 },
    radio:    { width: 20, height: 20, borderRadius: 10, borderWidth: 1.5, borderColor: C.t3, alignItems: 'center', justifyContent: 'center' },
    radioOn:  { borderColor: C.t1 },
    radioDot: { width: 10, height: 10, borderRadius: 5, backgroundColor: C.t1 },
    delete:   { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, marginTop: 28, height: 46, borderRadius: 12, borderWidth: 1, borderColor: C.border },
    deleteTxt:{ fontFamily: Fonts.semiBold, fontSize: 14, color: C.red },
  });
}
