import React, { useMemo, useState, useEffect, useCallback } from 'react';
import { View, Text, StyleSheet, Pressable, Share } from 'react-native';
import { Heart, MessageCircle, MoreHorizontal } from 'lucide-react-native';
import Svg, { Polyline, Polygon, Circle } from 'react-native-svg';
import { CityBackdrop } from '@mobile/shared/components/CityBackdrop';
import { Avatar } from '@mobile/shared/components/Avatar';
import { avatarColor } from '@shared/lib/avatarUtils';
import { fmtDistShort } from '@mobile/shared/lib/formatters';
import { TIER_CONFIG, formatArea } from '@shared/constants/territory';
import { fetchPostLikers, reportPost } from '@features/social/services/feedService';
import type { FeedPost, PostLiker } from '@features/social/types';
import { useTheme, useIsDark, Fonts, type AppColors } from '@theme';
import { territoryPalette } from '@theme/territory';
import PostActionsSheet from './PostActionsSheet';

function timeAgo(iso: string) {
  const diff = Date.now() - new Date(iso).getTime();
  const m = Math.floor(diff / 60000);
  if (m < 1)  return 'now';
  if (m < 60) return `${m}m`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h`;
  return `${Math.floor(h / 24)}d`;
}

function fmtTime(sec: number): string {
  const m = Math.floor(sec / 60);
  if (m >= 60) return `${Math.floor(m / 60)}h ${m % 60}m`;
  return `${m}m`;
}

function buildShareMessage(post: FeedPost): string {
  const tierLabel = post.territoryTier ? (TIER_CONFIG[post.territoryTier]?.label ?? post.territoryTier) : null;
  switch (post.postType) {
    case 'milestone':
      return `${post.username} just claimed their biggest zone yet on Runivo${tierLabel ? ` — ${tierLabel}` : ''}!`;
    case 'conquest':
      return `${post.username} captured ${post.stolenFromUsername ?? 'a rival'}'s territory on Runivo.`;
    case 'attack':
      return `${post.username}'s territory is under attack on Runivo — ${post.stolenFromUsername ?? 'a rival'} just struck.`;
    default:
      return `${post.username} ran ${fmtDistShort(post.distanceM)} km${post.avgPace ? ` at ${post.avgPace}/km` : ''} on Runivo.`;
  }
}

const MAP_W = 375;
const MAP_H = 150;
const STEAL_MAP_H = 170;
const PAD   = 22;

type HeroKind = 'run' | 'claim' | 'steal';

/** Route thumbnail over a drawn city, as on the mock's feed cards. */
function RouteMapHero({ points, seed, kind }: { points: { lat: number; lng: number }[]; seed: string; kind: HeroKind }) {
  const H = kind === 'steal' ? STEAL_MAP_H : MAP_H;
  const C  = useTheme();
  const zone = territoryPalette(useIsDark());
  const rm = useMemo(() => mkRmStyles(C), [C]);

  const geo = useMemo(() => {
    const lats  = points.map(p => p.lat);
    const lngs  = points.map(p => p.lng);
    const minLat = Math.min(...lats), maxLat = Math.max(...lats);
    const minLng = Math.min(...lngs), maxLng = Math.max(...lngs);
    // Longitude degrees shrink with latitude; correct so loops aren't stretched.
    const kx = Math.cos(((minLat + maxLat) / 2) * Math.PI / 180);
    const rangeW = (maxLng - minLng) * kx || 0.0001;
    const rangeH = maxLat - minLat || 0.0001;
    const scale  = Math.min((MAP_W - PAD * 2) / rangeW, (H - PAD * 2) / rangeH);
    const offX = (MAP_W - rangeW * scale) / 2, offY = (H - rangeH * scale) / 2;
    const pts = points.map(p => ({
      x: offX + (p.lng - minLng) * kx * scale,
      y: H - offY - (p.lat - minLat) * scale,
    }));
    const first = pts[0], last = pts[pts.length - 1];
    const diag = Math.hypot(rangeW * scale, rangeH * scale);
    const closed = Math.hypot(first.x - last.x, first.y - last.y) < Math.max(18, diag * 0.15);
    return { poly: pts.map(p => `${p.x.toFixed(1)},${p.y.toFixed(1)}`).join(' '), start: first, closed };
  }, [points, H]);

  const stroke = kind === 'run' ? C.t1 : zone.trail;
  const fill   = kind === 'run' ? '#FFFFFF' : zone.trail;
  const fillOpacity = kind === 'run' ? 0.55 : 0.18;

  return (
    <View style={rm.wrap}>
      <Svg width="100%" height={H} viewBox={`0 0 ${MAP_W} ${H}`} preserveAspectRatio="xMidYMid slice">
        <CityBackdrop width={MAP_W} height={H} seed={seed} />
        {geo.closed
          ? <Polygon points={geo.poly} fill={fill} fillOpacity={fillOpacity} stroke={stroke} strokeWidth={kind === 'steal' ? 2.5 : 3}
              strokeDasharray={kind === 'steal' ? '6 4' : undefined} strokeLinejoin="round" />
          : <Polyline points={geo.poly} fill="none" stroke={stroke} strokeWidth={3} strokeLinecap="round" strokeLinejoin="round" />}
        <Circle cx={geo.start.x} cy={geo.start.y} r="5" fill="#FFFFFF" stroke={stroke} strokeWidth="2.5" />
      </Svg>
    </View>
  );
}

function mkRmStyles(C: AppColors) {
  return StyleSheet.create({
    wrap: { backgroundColor: C.bg, overflow: 'hidden' },
  });
}

function StatBlock({ value, label, icon, color }: { value: string; label: string; icon?: React.ReactNode; color?: string }) {
  const C = useTheme();
  return (
    <View style={{ gap: 1, flex: 1 }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 3 }}>
        {icon}
        <Text style={{ fontFamily: Fonts.numeric, fontSize: 24, lineHeight: 24, color: color ?? C.t1, fontVariant: ['tabular-nums'] }}>{value}</Text>
      </View>
      <Text style={{ fontFamily: Fonts.medium, fontSize: 12, color: C.t2, marginTop: 3 }}>{label}</Text>
    </View>
  );
}

function KudosStack({ postId, kudosCount }: { postId: string; kudosCount: number }) {
  const C = useTheme();
  const s = useMemo(() => mkStackStyles(C), [C]);
  const [likers, setLikers] = useState<PostLiker[] | null>(null);

  useEffect(() => {
    let alive = true;
    if (kudosCount > 0) {
      fetchPostLikers(postId, 3)
        .then(l => { if (alive) setLikers(l.filter((x, i) => l.findIndex(y => y.id === x.id) === i)); })
        .catch(() => { if (alive) setLikers([]); });
    }
    return () => { alive = false; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [postId, kudosCount > 0]);

  if (kudosCount === 0 || !likers || likers.length === 0) return null;
  const extra = kudosCount - likers.length;

  return (
    <View style={s.wrap}>
      <View style={s.stack}>
        {likers.map((l, i) => (
          <View key={l.id} style={[s.ring, i > 0 && { marginLeft: -8 }]}>
            <Avatar name={l.username} color={l.avatarColor} size={17} uri={l.avatarUrl} />
          </View>
        ))}
      </View>
      <Text style={s.label} numberOfLines={1}>
        {likers.map(l => l.username).join(', ')}{extra > 0 ? ` +${extra}` : ''}
      </Text>
    </View>
  );
}

function mkStackStyles(C: AppColors) {
  return StyleSheet.create({
    wrap:  { flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 16, paddingBottom: 10, flexShrink: 1 },
    stack: { flexDirection: 'row', alignItems: 'center' },
    ring:  { borderRadius: 10, borderWidth: 1.5, borderColor: C.card },
    label: { fontFamily: Fonts.regular, fontSize: 11, color: C.t3, flexShrink: 1 },
  });
}

interface Props {
  post: FeedPost;
  currentUserId: string | null;
  onKudos: () => void;
  onComment: () => void;
  onUserPress?: () => void;
  onDelete: () => void;
  onDefend?: () => void;
}

// Memoised: the heaviest row in the app (renders a route polyline per post).
// FeedScreen already uses a useCallback renderItem — without memo here that win
// was cancelled, and every keystroke in the search box re-rendered every card.
export const FeedPostCard = React.memo(function FeedPostCard({
  post, currentUserId, onKudos, onComment, onUserPress, onDelete, onDefend,
}: Props) {
  const C = useTheme();
  const zone = territoryPalette(useIsDark());
  const s = useMemo(() => mkStyles(C), [C]);
  const [sheetOpen, setSheetOpen] = useState(false);

  const showRank = post.runnerRank && post.runnerRank !== 'pacer';
  const isOwnPost = currentUserId != null && post.userId === currentUserId;
  const activitySuffix = post.postType === 'run' && post.activityType !== 'run'
    ? ` · ${post.activityType === 'long_run' ? 'Long run' : post.activityType === 'cycle' ? 'Ride' : post.activityType === 'trail_run' ? 'Trail run' : post.activityType[0].toUpperCase() + post.activityType.slice(1)}`
    : '';

  const handleShare = useCallback(() => {
    Share.share({ message: buildShareMessage(post) }).catch(() => {});
  }, [post]);

  const handleReport = useCallback(() => reportPost(post.id, 'inappropriate').catch(() => {}), [post.id]);

  const tier = post.territoryTier ? (TIER_CONFIG[post.territoryTier] ?? TIER_CONFIG.patch) : null;
  const zoneTier = post.zoneTier ? (TIER_CONFIG[post.zoneTier] ?? null) : tier;
  const rankLabel = post.runnerRank ? post.runnerRank[0].toUpperCase() + post.runnerRank.slice(1) : null;
  const othersLine = post.hasKudos
    ? (post.kudosCount > 1 ? `You and ${post.kudosCount - 1} other${post.kudosCount - 1 === 1 ? '' : 's'}` : 'You')
    : null;

  // ── Steal ("kofi.k stole a zone from you") and conquest cards ─────────────
  if (post.postType === 'attack' || post.postType === 'conquest') {
    const attack = post.postType === 'attack';
    // On an attack post the author is you; the rival is stolen_from.
    const who = attack ? (post.stolenFromUsername ?? 'A rival') : post.username;
    const line = attack
      ? 'stole a zone from you'
      : `took a zone from ${post.stolenFromUsername ?? 'a rival'}`;
    return (
      <View style={s.card}>
        <View style={s.header}>
          <Pressable style={s.headerTap} onPress={attack ? undefined : onUserPress}>
            {attack
              ? <Avatar name={who} color={avatarColor(who)} size={36} uri={null} />
              : <Avatar name={post.username} color={post.avatarColor} size={36} uri={post.avatarUrl} />}
            <View style={s.userInfo}>
              <Text style={s.headline} numberOfLines={2}><Text style={s.username}>{who}</Text> {line}</Text>
              <Text style={s.subtitle}>{timeAgo(post.createdAt)}{zoneTier ? ` · ${zoneTier.label}` : ''}</Text>
            </View>
          </Pressable>
          <Pressable style={s.kebab} onPress={() => setSheetOpen(true)} hitSlop={10}>
            <MoreHorizontal size={18} color={C.t3} strokeWidth={2} />
          </Pressable>
        </View>
        {(post.routePoints?.length ?? 0) >= 5 && (
          <RouteMapHero points={post.routePoints!} seed={post.id} kind="steal" />
        )}
        <View style={s.stealFoot}>
          {post.stolenAreaM2 != null ? (
            <Text style={s.stealText}>
              <Text style={[s.stealArea, { color: attack ? zone.rival : zone.own }]}>
                {attack ? '' : '+'}{formatArea(post.stolenAreaM2)}
              </Text>
              {attack ? ' taken' : ' captured'}
            </Text>
          ) : <View />}
          {attack && onDefend && (
            <Pressable style={[s.takeBack, { backgroundColor: zone.own }]} onPress={onDefend} accessibilityRole="button">
              <Text style={s.takeBackText}>Take it back</Text>
            </Pressable>
          )}
        </View>
        <PostActionsSheet visible={sheetOpen} isOwnPost={isOwnPost} onClose={() => setSheetOpen(false)} onShare={handleShare} onDelete={onDelete} onReport={handleReport} />
      </View>
    );
  }

  // ── Milestone ("ana_runs claimed a District", black tier chip) ────────────
  if (post.postType === 'milestone') {
    return (
      <View style={s.card}>
        <View style={[s.header, s.headerCompact]}>
          <Pressable style={s.headerTap} onPress={onUserPress}>
            <Avatar name={post.username} color={post.avatarColor} size={36} uri={post.avatarUrl} />
            <View style={s.userInfo}>
              <Text style={s.headline} numberOfLines={2}>
                <Text style={s.username}>{post.username}</Text> claimed {tier ? `a ${tier.label}` : 'a new zone'}
              </Text>
              <Text style={s.subtitle}>
                {timeAgo(post.createdAt)}{post.territoryAreaM2 != null ? ` · ${formatArea(post.territoryAreaM2)}, biggest yet` : ''}
              </Text>
            </View>
          </Pressable>
          {tier && <View style={s.darkChip}><Text style={s.darkChipText}>{tier.label}</Text></View>}
        </View>
        {(post.routePoints?.length ?? 0) >= 5 && (
          <RouteMapHero points={post.routePoints!} seed={post.id} kind="claim" />
        )}
        <PostActionsSheet visible={sheetOpen} isOwnPost={isOwnPost} onClose={() => setSheetOpen(false)} onShare={handleShare} onDelete={onDelete} onReport={handleReport} />
      </View>
    );
  }

  // ── Run ───────────────────────────────────────────────────────────────────
  return (
    <View style={s.card}>
      <View style={s.header}>
        <Pressable style={s.headerTap} onPress={onUserPress}>
          <Avatar name={post.username} color={post.avatarColor} size={36} uri={post.avatarUrl} />
          <View style={s.userInfo}>
            <Text style={s.username}>{post.username}</Text>
            <Text style={s.subtitle}>{timeAgo(post.createdAt)}{activitySuffix}</Text>
          </View>
        </Pressable>
        {showRank && rankLabel && <View style={s.lightChip}><Text style={s.lightChipText}>{rankLabel}</Text></View>}
        <Pressable style={s.kebab} onPress={() => setSheetOpen(true)} hitSlop={10}>
          <MoreHorizontal size={18} color={C.t3} strokeWidth={2} />
        </Pressable>
      </View>

      <View style={s.statsRow}>
        <StatBlock value={fmtDistShort(post.distanceM)} label="km" />
        {post.avgPace ? <StatBlock value={post.avgPace} label="/km" /> : null}
        {tier ? <StatBlock value="+1" label="Zones" color={zone.own} /> : (post.durationSec > 0 ? <StatBlock value={fmtTime(post.durationSec)} label="Time" /> : null)}
        {post.paceEarned > 0 ? <StatBlock value={`+${post.paceEarned}`} label="PACE" /> : null}
      </View>

      {(post.routePoints?.length ?? 0) >= 5 && (
        <RouteMapHero
          points={post.routePoints!}
          seed={post.id}
          kind={post.territoryAreaM2 ? 'claim' : 'run'}
        />
      )}

      <View style={s.actions}>
        <Pressable style={s.actionBtn} onPress={onKudos} testID="feed-like-btn" accessibilityLabel="Kudos">
          <Heart size={16} color={post.hasKudos ? C.red : C.t2} fill={post.hasKudos ? C.red : 'none'} strokeWidth={1.8} />
          {post.kudosCount > 0 && <Text style={[s.actionCount, post.hasKudos && { color: C.red, fontFamily: Fonts.bold }]}>{post.kudosCount}</Text>}
        </Pressable>
        <Pressable style={s.actionBtn} onPress={onComment} testID="feed-comment-btn" accessibilityLabel="Comments">
          <MessageCircle size={16} color={C.t2} strokeWidth={1.8} />
          {post.commentCount > 0 && <Text style={s.actionCount}>{post.commentCount}</Text>}
        </Pressable>
        <View style={{ flex: 1 }} />
        {othersLine
          ? <Text style={s.othersText} numberOfLines={1}>{othersLine}</Text>
          : <KudosStack postId={post.id} kudosCount={post.kudosCount} />}
      </View>

      <PostActionsSheet
        visible={sheetOpen}
        isOwnPost={isOwnPost}
        onClose={() => setSheetOpen(false)}
        onShare={handleShare}
        onDelete={onDelete}
        onReport={handleReport}
      />
    </View>
  );
});

function mkStyles(C: AppColors) {
  return StyleSheet.create({
    card:         { backgroundColor: C.card, marginHorizontal: 18, marginBottom: 12, borderRadius: 16, overflow: 'hidden', shadowColor: '#14120F', shadowOpacity: 0.04, shadowRadius: 2, shadowOffset: { width: 0, height: 1 }, elevation: 1 },
    header:       { flexDirection: 'row', alignItems: 'center', gap: 8, paddingHorizontal: 14, paddingTop: 14, paddingBottom: 10 },
    headerCompact:{ paddingBottom: 14 },
    headerTap:    { flex: 1, flexDirection: 'row', alignItems: 'center' },
    kebab:        { padding: 4 },
    userInfo:     { flex: 1, marginLeft: 10 },
    headline:     { fontFamily: Fonts.regular, fontSize: 14, lineHeight: 18, color: C.t1 },
    username:     { fontFamily: Fonts.semiBold, fontSize: 14, lineHeight: 18, color: C.t1 },
    subtitle:     { fontFamily: Fonts.regular, fontSize: 12, color: C.t2, marginTop: 2 },
    lightChip:    { backgroundColor: '#F0EEE9', borderRadius: 6, paddingHorizontal: 8, paddingVertical: 4 },
    lightChipText:{ fontFamily: Fonts.semiBold, fontSize: 11.5, color: C.t1 },
    darkChip:     { backgroundColor: C.alwaysDark, borderRadius: 6, paddingHorizontal: 8, paddingVertical: 4 },
    darkChipText: { fontFamily: Fonts.semiBold, fontSize: 11.5, color: C.alwaysLight },
    statsRow:     { flexDirection: 'row', alignItems: 'flex-start', paddingHorizontal: 14, paddingBottom: 12 },
    stealFoot:    { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 10, paddingHorizontal: 14, paddingVertical: 12 },
    stealText:    { fontFamily: Fonts.regular, fontSize: 13, color: C.t2 },
    stealArea:    { fontFamily: Fonts.semiBold },
    takeBack:     { borderRadius: 999, paddingHorizontal: 12, height: 34, justifyContent: 'center' },
    takeBackText: { fontFamily: Fonts.semiBold, fontSize: 12.5, color: C.alwaysLight },
    actions:      { flexDirection: 'row', alignItems: 'center', gap: 18, paddingHorizontal: 14, paddingVertical: 12 },
    actionBtn:    { flexDirection: 'row', alignItems: 'center', gap: 6 },
    actionCount:  { fontFamily: Fonts.regular, fontSize: 13, color: C.t2, fontVariant: ['tabular-nums'] },
    othersText:   { fontFamily: Fonts.regular, fontSize: 12, color: C.t2, flexShrink: 1 },
  });
}
